#!/usr/bin/env python3
"""Guarded, no-Git overwrite of the exact Round 7H soulfire snapshot. No network access."""
import argparse, hashlib, json, os, shutil
from datetime import datetime
from pathlib import Path

PACKAGE = Path(__file__).resolve().parent
JAVA_ROOT = Path('src/main/java/spiderqueenhungrycraft')


def digest(path):
    data = Path(path).read_bytes()
    if Path(path).suffix == '.java':
        data = data.removeprefix(b'\xef\xbb\xbf').replace(b'\r\n', b'\n')
    return hashlib.sha256(data).hexdigest()


def main():
    ap = argparse.ArgumentParser(description='Install GPT-6 Round 7I reference source with strict SHA-256 checks')
    ap.add_argument('project', help='HungryCraft Gradle project root')
    ap.add_argument('--stage', type=int, choices=[1,2], required=True)
    ap.add_argument('--apply', action='store_true', help='Actually write after complete preflight; default dry-run')
    args = ap.parse_args()
    root = Path(args.project).resolve()
    if not root.is_dir() or not (root/'build.gradle').is_file():
        ap.error('REFUSE: project must exist and contain build.gradle')
    rows = json.loads((PACKAGE/'manifest.json').read_text(encoding='utf-8'))['stages'][str(args.stage)]
    actions = []
    denied = []
    for row in rows:
        rel = Path(row['path'])
        if rel.is_absolute() or '..' in rel.parts:
            raise ValueError('Invalid path in manifest: '+row['path'])
        source = PACKAGE/('stage'+str(args.stage))/rel
        target = root/JAVA_ROOT/rel
        if not source.is_file() or digest(source) != row['new_sha256']:
            denied.append(f'REFUSE: patch file missing or not matching manifest: {rel}')
            continue
        if not target.exists():
            if row['old_sha256'] is not None:
                denied.append(f'REFUSE: expected existing source missing: {target}')
                continue
            actions.append(('ADD',row,source,target))
            continue
        current = digest(target)
        if current == row['new_sha256']:
            print('ALREADY',rel)
            continue
        if current == row['old_sha256']:
            actions.append(('REPLACE',row,source,target))
            continue
        denied.append(f'REFUSE: source differs from exact Round 7H/7I baseline: {rel} SHA={current[:16]}')
    if denied:
        for line in denied: print(line)
        raise SystemExit(2)
    for action,row,_,_ in actions:
        print('READY',action,row['path'])
    if not args.apply:
        print('DRY-RUN PASS |',len(actions),'pending | run with --apply if appropriate')
        return
    if not actions:
        print('Nothing to change. Existing source already matches all Stage',args.stage,'files.')
        return
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    backup=root.parent/'_soulfire7i_external_backups'/('stage'+str(args.stage)+'_'+timestamp)
    backup.mkdir(parents=True,exist_ok=False)
    report={'stage':args.stage,'project':str(root),'entries':[]}
    # Back up EVERY replacement BEFORE writing the first file.
    for action,row,_,target in actions:
        oldrel=Path('original')/row['path']
        if action=='REPLACE':
            dest=backup/oldrel;dest.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(target,dest)
            assert digest(dest)==row['old_sha256'], 'Backup failed verification'
        report['entries'].append({'action':action,**row})
    (backup/'backup.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    for action,row,source,target in actions:
        target.parent.mkdir(parents=True,exist_ok=True)
        temp=target.with_name(target.name+'.soulfire7i_tmp')
        if temp.exists():
            raise RuntimeError('REFUSE: temporary file already exists: '+str(temp))
        temp.write_bytes(source.read_bytes())
        assert digest(temp)==row['new_sha256']
        os.replace(temp,target)
        print('APPLIED',action,row['path'])
    print('EXTERNAL BACKUP:',backup)
    print('Please compile and test now; this package is NOT Forge-build-verified.')

if __name__=='__main__': main()
