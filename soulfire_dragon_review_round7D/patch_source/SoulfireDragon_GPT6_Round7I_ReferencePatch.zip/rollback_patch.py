#!/usr/bin/env python3
"""Reverts only files recorded by one GPT-6 7I installer backup, with SHA guards."""
import argparse, hashlib, json, os, shutil
from pathlib import Path
JAVA_ROOT=Path('src/main/java/spiderqueenhungrycraft')

def sha(path):
    data=Path(path).read_bytes().removeprefix(b'\xef\xbb\xbf').replace(b'\r\n',b'\n')
    return hashlib.sha256(data).hexdigest()

def main():
    parser=argparse.ArgumentParser(description='Safely roll back a specific 7I stage backup')
    parser.add_argument('project');parser.add_argument('backup')
    args=parser.parse_args()
    root=Path(args.project).resolve(); backup=Path(args.backup).resolve()
    if not (root/'build.gradle').is_file(): parser.error('REFUSE: invalid Gradle project')
    info=json.loads((backup/'backup.json').read_text(encoding='utf-8'))
    if str(root)!=info['project']: parser.error('REFUSE: backup belongs to another project')
    for row in info['entries']:
        target=root/JAVA_ROOT/row['path']
        if not target.is_file() or sha(target)!=row['new_sha256']:
            parser.error('REFUSE: current file was modified after 7I patch: '+str(target))
        if row['action']=='REPLACE':
            origin=backup/'original'/row['path']
            if not origin.is_file() or sha(origin)!=row['old_sha256']:
                parser.error('REFUSE: damaged backup '+str(origin))
    # Every file validated before touching one.
    for row in info['entries']:
        target=root/JAVA_ROOT/row['path']
        if row['action']=='ADD':
            target.unlink()
        else:
            origin=backup/'original'/row['path']
            tmp=target.with_name(target.name+'.soulfire7i_rollback_tmp')
            if tmp.exists(): parser.error('REFUSE: leftover temporary file '+str(tmp))
            shutil.copyfile(origin,tmp)
            os.replace(tmp,target)
        print('ROLLED BACK',row['path'])
    print('Done. Other untracked/dirty files were untouched.')
if __name__=='__main__': main()
