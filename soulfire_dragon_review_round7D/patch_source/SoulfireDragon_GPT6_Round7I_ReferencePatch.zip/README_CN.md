# HungryCraft / 灵火龙：GPT-6 Round 7I 参考源码补丁

**定位**：基于玩家上传的 Round 7H（5.28 MB）实际 Java 文件，逐处编辑的**源码参考包**，不是已编译 JAR，也不是已在 Minecraft 中验证的成品。

## 本包修什么

第一阶段（Stage 1，先装先测）：
- `SoulfireDragonEntity`：空中按飞行目标方向以每 tick 不超过 8° 的速度转动**真实实体朝向**，横向运动与朝向一致；面对身后目标时原地转身，避免倒着或横着飞。
- 通过 `SynchedEntityData` 把服务端 `BODY_YAW` 和 `AIR_BANK` 同步给客户端。同步 `LANDING`、`LANDING_BLEND`，让动画真正知道龙正在降落。
- `SoulfireDragonAnimator`：继续使用 I&F 的六个 `FLIGHT`、四个 `WALK` 原版姿态，叠加 I&F `HOVERING_POSE`、`DIVING_POSE` 和 `GROUND_POSE` 的降落混合；转向时仅给原骨架 `BodyUpper` / `armL1` / `armR1` 施加轻微倾斜；改成逐实体平滑头颈朝向，缓解吐息时头部抖动。
- `Soulfire7IFlightGameTest`：检测**实际速度方向**与模型/实体朝向一致，而不是只测试命令状态。

第二阶段（Stage 2，Stage 1 真机通过才装）：
- 删除 `ensurePartsInWorld()` 对 `PartEntity` 的 `addFreshEntity(part)`。Forge 已对主实体返回的缓存 `getParts()` 提供跟踪注册，这些部件不应该作为独立普通实体添加。
- 客户端/服务端统一 `DATA_BODY_YAW`，连地面状态也对齐。修复上轮已测到的 ~58.6° 端间偏差。
- 按 7G 量出的模型吻端与体型缩放，重排头、颈、胸、翼、尾六个现有部件的位置。**属于模型近似命中，不是逐像素骨骼蒙皮**。
- 扩展 `getBoundingBoxForCulling()`；身体中心出视野但翼骨还在画面中时，不再被小主体碰撞箱直接剔除。
- 渲染器 F3+B 时额外以青色绘制**实际客户端 `PartEntity` AABB**，不再依赖游戏是否自动渲染部件框。
- `Soulfire7IMultipartGameTest`：检查世界对真实 part ID 的注册、部件可点击、渲染剔除框以及龙头与模型吻端的距离。

⚠️ **别把 F3+B 六个方框当作命中成功**：必须在真人客户端分别用真实箭矢、近战以及蛛后单选测试头部/翅膀/尾巴。F3+B 是辅助可视化，服务端攻击查询必须单独证明。

## 文件及覆盖范围

Stage 1：
- 替换 `src/main/java/spiderqueenhungrycraft/soulfire/SoulfireDragonEntity.java`
- 替换 `src/main/java/spiderqueenhungrycraft/compat/iceandfire/client/SoulfireDragonAnimator.java`
- 新增 `src/main/java/spiderqueenhungrycraft/soulfire/Soulfire7IFlightGameTest.java`

Stage 2：
- 再替换 Stage 1 的 `SoulfireDragonEntity.java`（按 Stage 1 结果哈希校验）
- 替换 `src/main/java/spiderqueenhungrycraft/compat/iceandfire/client/SoulfireIafDragonRenderer.java`
- 新增 `src/main/java/spiderqueenhungrycraft/soulfire/Soulfire7IMultipartGameTest.java`

**从未触碰**：`SoulfireRising`、契约恢复台账、RTS 命令执行器、权杖选择、骑乘和吐息的服务端伤害逻辑。不实现发光眼睛（用户明确决定不再做）。不引入 I&F 原生实体或 AI。

## 使用方法（Windows PowerShell）

先解压 ZIP 到 HungryCraft 工程**之外**，用命令行进入解压目录：

```powershell
py -3 .\apply_patch.py "D:\MinecraftModding\实际项目根目录" --stage 1
```

默认是只读 dry-run。出现 `READY` 且没有 `REFUSE`，再执行：

```powershell
py -3 .\apply_patch.py "D:\MinecraftModding\实际项目根目录" --stage 1 --apply
```

脚本仅对 `manifest.json` 内的文件写入，逐项 SHA-256 校验，自动在**项目同级的独立目录**备份本轮将覆盖的源码。**如 SHA 不匹配，绝不强制覆盖**；应让 DS 定向合并（并记录版本）。

使用 Gradle 编译：

```powershell
.\gradlew.bat compileJava
.\gradlew.bat runGameTestServer
```

实际启动装有 I&F 的客户端，确认开阔地：东西南北四个 MOVE 转向、180° 反向 MOVE、落地过渡姿态、喷吐时的头部稳定性、原版骨翼动作。**如果失败，请停在 Stage 1，把第一个编译错误或实机录像/日志发回，不要安装 Stage 2**。

Stage 1 通过后，原理一样：

```powershell
py -3 .\apply_patch.py "D:\MinecraftModding\实际项目根目录" --stage 2
py -3 .\apply_patch.py "D:\MinecraftModding\实际项目根目录" --stage 2 --apply
```

Stage 2 人工验收：
1. F3+B 观察六个青色部件框（不只是一个中心框），截图证据。
2. 弓箭在头、颈、左右翼、尾部框内射击，查看主体血量；近战需要符合实际攻击距离，不可在 10 格外拿剑砍翅膀然后说没判定。
3. 游戏内普通左键点中远离主体的翼/尾，查看伤害和单位归属、选择链路。
4. 站定与飞行时，两侧 PartEntity 与模型朝向一致；收集服务端/客户端的 `yBodyRot`、每段 AABB 中心。
5. 摄像机只看见尾巴或翅膀时模型不突然消失；高空 MOVE/HOLD/FOLLOW 仍能安全落地。
6. Stage 1/2 GameTest 绿，普通蜘蛛、无 I&F 加载、原始遗骸恢复不回归。

回滚：安装器每次打印备份目录，按**Stage 2 后 Stage 1**顺序调用：

```powershell
py -3 .\rollback_patch.py "D:\MinecraftModding\实际项目根目录" "备份目录的完整路径"
```

回滚前检查当前文件内容确实与本补丁哈希一致，防止覆盖 DS 新改的代码。

## 重要限制

- 我这里没有完整 Forge 47.4.23 Gradle 依赖缓存和可启动的 Minecraft 实例：**没有执行真实 `compileJava`、GameTest 和玩法验收**。
- I&F 姿态取的是本地源码和官方公开 `DragonAnimationsLibrary`、`DragonTabulaModelAnimator` API 做的适配。姿态叠加的方向/强度仍需玩家肉眼标定；不是复制或重新启用 I&F AI。
- 7H 用的是六个较粗略的 `PartEntity` 命中框。此次先修**可查询、朝向和位置、可视化、剔除**四个根因；不宣称已经实现 I&F 按翼骨、尾骨逐节完全相同的 10 段模型。需要进一步增加更多节段时，以本轮真机证据为依据。
- Forge `PartEntity` 由主实体生命周期管理，`getParts()` 返回稳定缓存，不应被当成会独立存档/寻路的实体。
- 自动测试中有简化模型尺寸断言，任何测试失败都应针对真实源码和世界坐标调整，不能仅为测试通过而改掉产品行为。
- 严禁 `git reset/clean/checkout/commit/add/stash` 等破坏或改变当前工作状态的操作。
