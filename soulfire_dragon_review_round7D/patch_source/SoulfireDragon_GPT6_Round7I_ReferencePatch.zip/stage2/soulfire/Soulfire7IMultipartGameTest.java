package spiderqueenhungrycraft.soulfire;

import net.minecraft.core.BlockPos;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.entity.PartEntity;
import net.minecraftforge.gametest.GameTestHolder;
import net.minecraftforge.gametest.PrefixGameTestTemplate;
import spiderqueenhungrycraft.SpiderQueenHungryCraft;
import spiderqueenhungrycraft.registry.HungryCraftEntities;

/** Server half of the real 7I multipart proof; F3+B and client clicking still require human review. */
@GameTestHolder(SpiderQueenHungryCraft.MODID)
@PrefixGameTestTemplate(false)
public final class Soulfire7IMultipartGameTest
{
    private Soulfire7IMultipartGameTest() {}

    @GameTest(template = "humanspawn_flat", batch = "soulfire7i_parts", timeoutTicks = 100)
    public static void realpartindexesandcullingenvelope(GameTestHelper helper)
    {
        SoulfireDragonEntity dragon = helper.spawn(HungryCraftEntities.SOULFIRE_DRAGON.get(), new BlockPos(2, 1, 2));
        ServerLevel level = helper.getLevel();
        final int[] ticks = {0};
        helper.onEachTick(() ->
        {
            ticks[0]++;
            if (ticks[0] != 10) return;
            PartEntity<?>[] parts = dragon.getParts();
            if (parts == null || parts.length != 6)
            {
                helper.fail("expected cached six parts, got " + (parts == null ? "null" : parts.length));
                return;
            }
            AABB culling = dragon.getBoundingBoxForCulling();
            for (PartEntity<?> part : parts)
            {
                if (level.getEntityOrPart(part.getId()) != part)
                {
                    helper.fail("ServerLevel has no real mapped part " + part.getId());
                    return;
                }
                if (!part.isPickable())
                {
                    helper.fail("part is not targetable " + part.getId());
                    return;
                }
                Vec3 centre = part.getBoundingBox().getCenter();
                if (!culling.contains(centre))
                {
                    helper.fail("culling envelope misses a real hitbox " + part.getId());
                    return;
                }
            }
            Vec3 muzzle = dragon.getMuzzlePosition();
            Vec3 head = parts[0].getBoundingBox().getCenter();
            if (muzzle.distanceTo(head) > 2.8D * dragon.getSoulScale())
            {
                helper.fail("head hitbox not near drawn muzzle, distance=" + muzzle.distanceTo(head));
                return;
            }
            helper.succeed();
        });
    }
}
