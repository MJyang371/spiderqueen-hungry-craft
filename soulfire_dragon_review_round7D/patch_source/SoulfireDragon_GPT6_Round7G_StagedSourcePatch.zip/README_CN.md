# HungryCraft / 灵火龙 Round 7G — GPT-6 增量修复包

> **源码补丁，不是编译完成的 Mod JAR。** 基于玩家上传的 **Round 7F** ZIP 中同名 Java 文件制作，不包含 I&F 第三方资产。本包未经 Forge Gradle 编译或游戏实机验证；必须由 DS 在当前项目副本中编译与测试。

## 根因（已从 Round 7F 上传源码定位）

1. **动画**：`SoulfireDragonAnimator.setRotationAngles` 虽挑选了 I&F 姿态，但调用 `moveToPose` 并不等价于每帧把 pose 的骨骼角度写回 104 部件的 Tabula 实例；已补上 `WALK1–4`、`FLIGHT1–6` 姿态角/支点逐帧插值，GROUND/SITTING 直接设置，吐息只驱动头/颈/颚。**这是姿态插值实现，不能保证与原版所有细节动画完全一样。**
2. **FOLLOW 穿模**：之前以玩家脚下为导航终点、停止半径约 6 格。7G 改成可调**跟随环形阵位**、最少 14 格、四阶段龙约 18 格，并增加 5 格滞回，避免巨大骨架顶进主人。
3. **吐息起点**：之前固定 `look*1.6 + height*.72`，没有匹配龙头。阶段一改为按成长阶段和头朝向估算，阶段二可选按真正的服务器头部命中箱校准，**仍需实机标定口部精确位置**。
4. **发光眼睛**：加入只在 I&F 渲染分支使用的蓝青色 `RenderType.eyes` 叠层与独立眼光贴图，随 Tabula `Head` 骨骼父链运动；眼眶局部坐标是**待游戏画面标定的初始值**，不保证一次对齐。
5. **多部位碰撞**：Round 7F 完全没有 `PartEntity`，只有一个 `.sized(3,3.5)` 主箱。本包**第二阶段可选实验**增加六个战斗命中部件（头、颈、躯干、左右翼、尾部），同步年龄阶段体型；不改变基础物理碰撞对方块的处理。此部分风险高，须在**独立测试世界**逐项验证，尤其命中、射线选择、存档重载、实体 ID 与重复结算伤害。

## 两阶段、不可一次覆盖全部

### Stage 1（建议先应用，6 Java + 1 PNG）

- `soulfire/SoulfireDragonEntity.java` — 龙嘴位置阶段化估算。
- `soulfire/goal/SoulfireCommandGoal.java` — 环形 FOLLOW、停走滞回。
- `compat/iceandfire/client/SoulfireDragonAnimator.java` — Tabula 真实骨骼姿态插值。
- `compat/iceandfire/client/SoulfireIafTabulaModel.java` — 委托模型可让眼层取得真正 Tabula 模型；**保持 vanilla `EntityModel` 继承，禁止回归 Citadel 直接继承的 SRG 命名冲突**。
- `compat/iceandfire/client/SoulfireIafDragonRenderer.java` — 注册眼层。
- 新增 `compat/iceandfire/client/SoulfireEyesLayer.java` + `textures/entity/soulfire_eye_glow.png`。

### Stage 2（可选实验，四份 Java；Stage 1 编译且实机通过后才考虑）

- `soulfire/SoulfireDragonEntity.java` — 六个 `PartEntity`、按阶段缩放主碰撞箱、服务端部位定位，龙嘴跟随头部命中区。
- 新增 `soulfire/SoulfireDragonPart.java` — 子部位，不独立生成/NBT，伤害交给主体。
- `soulfire/SoulfireOrders.java` — 框选单位时对子部位反查主实体并去重。
- `brood/BroodSelection.java` — 单位选择接口对子部位反查主体。

**特别注意：** 玩家点击选中还可能经过 `QueenCommandRay`（此类不在上传的评审 ZIP 中）。这份 Stage 2 **并不保证所有射线入口已经兼容**，必须由 DS 检查完整工程。实际 F3+B 命中框也必须由玩家验证。由于子部位不是完整追随客户端模型每帧动画的骨骼，当前六箱是保守的服务端近似位置，**并不是逐骨骼一致的 I&F 原生多段碰撞**。

## 使用步骤（建议在项目副本）

把 ZIP 解压到工程之外，例如 `D:\MinecraftModding\_patches\Soulfire7G`；若没有安装 Python 或项目结构不匹配，让 DS 对照文件手工合并，**不要强行覆盖不匹配哈希**。

```powershell
# 先检查，默认不写任何东西
py -3 .\apply_patch.py "D:\MinecraftModding\HungryCraft" --stage 1
# 所有 READY 后才应用
py -3 .\apply_patch.py "D:\MinecraftModding\HungryCraft" --stage 1 --apply
# 由 DS 编译、测试，再进入实机
.\gradlew.bat compileJava
.\gradlew.bat runGameTestServer
# 仅 Stage 1 完整通过且完成备份后再选择安装 Stage 2
py -3 .\apply_patch.py "D:\MinecraftModding\HungryCraft" --stage 2
py -3 .\apply_patch.py "D:\MinecraftModding\HungryCraft" --stage 2 --apply
```

安装器的 `--stage 2` 只检查 stage2 列出的文件（特别是 Stage1 实体文件哈希），**必须先进行 Stage1**。安装器会在工程目录的同级目录建立时间戳备份，包含所有被覆盖文件；增加文件的删除与恢复请按备份中的 `backup_manifest.json` 手动执行。禁止直接 `git reset/clean/checkout` 处理玩家 300+ 脏文件。

## 实机验收（不接受“仅仅编译成功”）

- 站立、行走、飞行、悬停、降落、驻守：I&F 原版骨龙 **有真实翼骨/腿/颈的相对动作**，不是整条骨架平移或只有位置变化。
- 体型四阶段龙 FOLLOW：停在玩家 **约 18 格**，远处重追/附近保持，**不能推人穿模**；重复快速移动观察是否抽搐。
- 直线喷息：蓝色火焰从**龙口而不是胸部/头顶**开始；若还有错位，记录龙成长阶段、朝向、GameTest 世界坐标及截图，校准常数。
- 蓝眼睛：发光片必须在真正的**眼眶**，不浮空、不穿骨，白天/黑夜可见。不是贴图涂蓝就算完成。
- 可选 Stage 2：F3+B 六个部位存在；弓射翼骨/尾骨能扣**主体一次生命值**；不发生同次攻击重复结算；单击/框选正确选择主人实体、他人不能控制；不同阶段大小匹配；无 I&F 与专用服务端不崩溃。
- 既有 Round7F：高空 HOLD、远程 MOVE 和 FOLLOW 最终 `onGround && !flying && !hovering && !landing && !noGravity`，应继续通过。

## 本包不能解决的事项

- I&F 原火龙龙息同款投射特效/遮挡伤害/冷却 **尚未修改**，只是吐息的起点更接近嘴部。
- 龙的骑乘仍被代码显式禁止；不在本轮。
- 多段命中并不自动等于多段“实体物理阻挡”或完美同步客户端模型。
- 日志中 `RenderLayer` 或 Citadel API 如果出现签名错误，必须按真实 I&F/Citadel jar 修复；**不允许因此删除整个 Tabula 渲染方案或恢复自制方块龙**。
- **没有本地 Forge 实际编译及游戏验收记录**。详见 `VALIDATION.txt`。
