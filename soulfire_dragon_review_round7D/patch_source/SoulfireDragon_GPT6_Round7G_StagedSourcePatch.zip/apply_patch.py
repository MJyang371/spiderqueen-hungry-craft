#!/usr/bin/env python3
"""Guarded Stage 1 / Stage 2 source install; no destructive Git operations."""
import argparse
import hashlib
import json
import shutil
import sys
from datetime import datetime
from pathlib import Path


def digest(path: Path) -> str:
    # Normalize CRLF/BOM only for identifying source versions.
    data = path.read_bytes()
    if path.suffix == '.java':
        data = data.removeprefix(b'\xef\xbb\xbf').replace(b'\r\n', b'\n')
    return hashlib.sha256(data).hexdigest()


def main():
    parser = argparse.ArgumentParser(description='Soulfire 7G safe source installer (default: dry run)')
    parser.add_argument('project', type=Path, help='Gradle project root')
    parser.add_argument('--stage', choices=['1', '2'], default='1')
    parser.add_argument('--apply', action='store_true', help='Apply after all hashes match')
    args = parser.parse_args()
    source_root = Path(__file__).resolve().parent
    project = args.project.expanduser().resolve()
    manifest = json.loads((source_root / 'manifest.json').read_text(encoding='utf-8'))
    stage = args.stage
    java_root = project / 'src/main/java/spiderqueenhungrycraft'
    resources_root = project / 'src/main/resources/assets/spiderqueen_hungrycraft'
    if not (project / 'build.gradle').is_file() or not java_root.is_dir():
        sys.exit('REFUSE: No build.gradle or src/main/java/spiderqueenhungrycraft at supplied project root')
    changes = []
    for ent in manifest['stages'][stage]:
        target_root = java_root if ent['kind'] == 'java' else resources_root
        target = target_root / ent['path']
        source = source_root / ('stage' + stage + '_patch') / ent['path']
        if not source.is_file() or digest(source) != ent['new_sha256']:
            sys.exit('REFUSE: ZIP patch contents do not match manifest: ' + str(source))
        expected = ent.get('old_sha256')
        if expected is None:
            if target.exists():
                if digest(target) == ent['new_sha256']:
                    print('ALREADY INSTALLED new', ent['path']); continue
                sys.exit('REFUSE: would overwrite nonempty existing new file: ' + str(target))
        else:
            if not target.is_file():
                sys.exit('REFUSE: existing source not found: ' + str(target))
            found = digest(target)
            if found == ent['new_sha256']:
                print('ALREADY INSTALLED replace', ent['path']); continue
            if found != expected:
                sys.exit('REFUSE: SHA-256 mismatch, must merge manually: ' + str(target)
                         + '\nExpected ' + expected + '\nFound    ' + found)
        changes.append((ent, source, target))
        print('READY', ent['kind'], ent['path'])
    if not changes:
        print('Nothing to change.'); return
    if not args.apply:
        print('DRY RUN PASS:', len(changes), 'files; rerun with --apply to write.'); return
    # Backup lives OUTSIDE the project (nothing touches .git / worlds / other mods).
    name = datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    backup = project.parent / ('_Soulfire7G_stage' + stage + '_backup_' + name)
    backup.mkdir(parents=True, exist_ok=False)
    saved = []
    try:
        for ent, source, target in changes:
            if target.is_file():
                save = backup / ent['kind'] / ent['path']
                save.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(target, save)
                saved.append({'kind': ent['kind'], 'path': ent['path'], 'backup': str(save)})
        (backup / 'backup_manifest.json').write_text(json.dumps({'stage': stage, 'project': str(project),
            'originals': saved, 'created': [{'kind': x['kind'], 'path': x['path']} for x,_,t in changes if not t.exists()]},
            ensure_ascii=False, indent=2), encoding='utf-8')
        for ent, source, target in changes:
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source, target)
            print('APPLIED', target)
    except Exception:
        # Restore only this install's touched files, nothing else.
        for ent, _, target in reversed(changes):
            save = backup / ent['kind'] / ent['path']
            if save.is_file(): shutil.copy2(save, target)
            elif target.is_file() and digest(target) == ent['new_sha256']: target.unlink()
        raise
    print('APPLY SUCCESS. External backup:', backup)
    print('Run ./gradlew compileJava and actual in-game tests. No build/runtime assertions are implied.')

if __name__ == '__main__':
    main()
