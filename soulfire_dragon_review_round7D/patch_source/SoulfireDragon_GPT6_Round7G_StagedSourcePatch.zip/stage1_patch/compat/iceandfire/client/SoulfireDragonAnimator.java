package spiderqueenhungrycraft.compat.iceandfire.client;

import com.github.alexthe666.citadel.client.model.ITabulaModelAnimator;
import com.github.alexthe666.citadel.client.model.TabulaModel;
import com.github.alexthe666.citadel.client.model.AdvancedModelBox;
import net.minecraft.util.Mth;
import com.github.alexthe666.iceandfire.client.model.animator.IceAndFireTabulaModelAnimator;
import com.github.alexthe666.iceandfire.client.model.util.DragonAnimationsLibrary;
import com.github.alexthe666.iceandfire.client.model.util.EnumDragonModelTypes;
import com.github.alexthe666.iceandfire.client.model.util.EnumDragonPoses;
import com.github.alexthe666.iceandfire.client.model.util.IEnumDragonModelTypes;
import com.github.alexthe666.iceandfire.client.model.util.IEnumDragonPoses;

import spiderqueenhungrycraft.soulfire.SoulfireDragonEntity;

/**
 * The animation adapter of the soul fire dragon (round 7F, restored pose adapter).
 *
 * <p><b>It is an adapter, not a copy.</b> Ice and Fire's own dragon animator is bound to {@code EntityDragonBase}
 * ({@code DragonTabulaModelAnimator<T extends EntityDragonBase>}) and can therefore never animate a unit of this mod,
 * but its <b>parent</b> {@link IceAndFireTabulaModelAnimator} is a plain, entity free class of public helpers
 * ({@code moveToPose}, {@code transitionTo}, {@code rotate}, {@code distance}). This class extends it and implements
 * Citadel's generic {@link ITabulaModelAnimator} for {@link SoulfireDragonEntity}, so the model geometry, the poses and
 * the interpolation helpers are Ice and Fire's, while the decision "which pose to show right now" is ours
 * (standing, walking, flying, sitting or breathing) and reads only this mod's own state.
 *
 * <p>The pose sets are fetched <b>lazily</b> from {@link DragonAnimationsLibrary} and every use is null guarded: the
 * library is filled by Ice and Fire's own client setup, and a frame that happens before that simply shows the default
 * pose instead of failing.
 */
public class SoulfireDragonAnimator extends IceAndFireTabulaModelAnimator
        implements ITabulaModelAnimator<SoulfireDragonEntity>
{
    /** The one model kind every soul fire dragon is drawn with, whatever remains it was raised from. */
    public static final IEnumDragonModelTypes MODEL_TYPE = EnumDragonModelTypes.FIRE_DRAGON_MODEL;

    private TabulaModel[] walkPoses;
    private TabulaModel[] flyPoses;
    private TabulaModel groundPose;
    private TabulaModel sittingPose;

    public SoulfireDragonAnimator()
    {
        this(MODEL_TYPE);
    }

    public SoulfireDragonAnimator(IEnumDragonModelTypes modelType)
    {
        // Exactly the wiring of Ice and Fire's own animators: the base model comes from the library the mod fills in
        // its client setup, which is the same model the renderer is handed.
        super(DragonAnimationsLibrary.getModel(EnumDragonPoses.GROUND_POSE, modelType));
    }

    /**
     * The I&F pose library stores FULL Tabula poses, not ready-to-run vanilla animation clips.
     * IceAndFireTabulaModelAnimator.moveToPose() constructs an animation keyframe delta;
     * calling it outside Citadel's active keyframe animation produces a static sculpture.
     * This renderer has no EntityDragonBase/IAnimatedEntity keyframe driver by design.
     * Instead, interpolate the REAL pose boxes each render frame, matching by their names.
     * There are NO custom wing cubes and NO dependence on the old 7D model.
     */
    @Override
    public void setRotationAngles(TabulaModel model, SoulfireDragonEntity entity, float limbSwing,
            float limbSwingAmount, float ageInTicks, float rotationYaw, float rotationPitch, float scale)
    {
        model.resetToDefaultPose();
        this.ensurePoses();

        if (entity.isFlying() || entity.isHovering())
        {
            // 6 genuine I&F flight poses, interpolated over 60 ticks: no teleporting wings.
            this.applyCycle(model, this.flyPoses, ageInTicks, 10.0F, 1.0F);
        }
        else if (entity.isSitting())
        {
            this.applyPose(model, this.sittingPose, this.sittingPose, 0.0F, 1.0F);
        }
        else if (limbSwingAmount > 0.035F)
        {
            // 4 I&F walk poses. LimbSwing comes from the vanilla walk animation state.
            float phase = limbSwing * 0.16F;
            this.applyCycle(model, this.walkPoses, phase, 1.0F, Mth.clamp(limbSwingAmount * 3.0F, 0.0F, 1.0F));
        }
        else
        {
            this.applyPose(model, this.groundPose, this.groundPose, 0.0F, 1.0F);
        }

        // I&F stream-breath pose gives the jaws their original dragon-mouth gesture.
        if (entity.isBreathing())
        {
            TabulaModel stream = this.get(EnumDragonPoses.STREAM_BREATH);
            if (stream != null)
            {
                this.applyBreathingHead(model, stream);
            }
        }
    }

    private void applyBreathingHead(TabulaModel model, TabulaModel stream)
    {
        for (AdvancedModelBox part : model.getCubes().values())
        {
            String name = part.boxName.toLowerCase(java.util.Locale.ROOT);
            if (!(name.contains("head") || name.contains("jaw") || name.startsWith("neck")))
            {
                continue;
            }
            AdvancedModelBox pose = stream.getCubes().get(part.boxName);
            if (pose != null)
            {
                part.rotateAngleX = Mth.lerp(0.75F, part.rotateAngleX, pose.rotateAngleX);
                part.rotateAngleY = Mth.lerp(0.75F, part.rotateAngleY, pose.rotateAngleY);
                part.rotateAngleZ = Mth.lerp(0.75F, part.rotateAngleZ, pose.rotateAngleZ);
            }
        }
    }

    private void applyCycle(TabulaModel base, TabulaModel[] poses, float time, float ticksPerPose, float strength)
    {
        if (poses == null || poses.length == 0)
        {
            return;
        }
        // Missing poses should not freeze the whole model: degrade to GROUND.
        float phase = Math.max(0.0F, time / ticksPerPose);
        int first = (int) Math.floor(phase) % poses.length;
        int second = (first + 1) % poses.length;
        this.applyPose(base, poses[first], poses[second], phase - (float) Math.floor(phase), strength);
    }

    private void applyPose(TabulaModel target, TabulaModel first, TabulaModel second, float alpha, float weight)
    {
        if (first == null || second == null)
        {
            return;
        }
        // Mapping by stable I&F box names also works if some pose lacks one optional box.
        for (AdvancedModelBox part : target.getCubes().values())
        {
            AdvancedModelBox a = first.getCubes().get(part.boxName);
            AdvancedModelBox b = second.getCubes().get(part.boxName);
            if (a == null || b == null)
            {
                continue;
            }
            part.rotateAngleX = Mth.lerp(weight, part.rotateAngleX, Mth.lerp(alpha, a.rotateAngleX, b.rotateAngleX));
            part.rotateAngleY = Mth.lerp(weight, part.rotateAngleY, Mth.lerp(alpha, a.rotateAngleY, b.rotateAngleY));
            part.rotateAngleZ = Mth.lerp(weight, part.rotateAngleZ, Mth.lerp(alpha, a.rotateAngleZ, b.rotateAngleZ));
            part.rotationPointX = Mth.lerp(weight, part.rotationPointX, Mth.lerp(alpha, a.rotationPointX, b.rotationPointX));
            part.rotationPointY = Mth.lerp(weight, part.rotationPointY, Mth.lerp(alpha, a.rotationPointY, b.rotationPointY));
            part.rotationPointZ = Mth.lerp(weight, part.rotationPointZ, Mth.lerp(alpha, a.rotationPointZ, b.rotationPointZ));
        }
    }

    /** Reads the pose sets of this dragon kind out of Ice and Fire's library, once, and never fails when it is empty. */
    private void ensurePoses()
    {
        if (this.groundPose != null)
        {
            return;
        }

        this.groundPose = get(EnumDragonPoses.GROUND_POSE);
        this.sittingPose = get(EnumDragonPoses.SITTING_POSE);
        this.walkPoses = new TabulaModel[] { get(EnumDragonPoses.WALK1), get(EnumDragonPoses.WALK2),
                get(EnumDragonPoses.WALK3), get(EnumDragonPoses.WALK4) };
        this.flyPoses = new TabulaModel[] { get(EnumDragonPoses.FLIGHT1), get(EnumDragonPoses.FLIGHT2),
                get(EnumDragonPoses.FLIGHT3), get(EnumDragonPoses.FLIGHT4), get(EnumDragonPoses.FLIGHT5),
                get(EnumDragonPoses.FLIGHT6) };
    }

    private TabulaModel get(IEnumDragonPoses pose)
    {
        return DragonAnimationsLibrary.getModel(pose, MODEL_TYPE);
    }
}
