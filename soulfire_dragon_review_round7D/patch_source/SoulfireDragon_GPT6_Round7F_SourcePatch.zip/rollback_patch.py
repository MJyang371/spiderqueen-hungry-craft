#!/usr/bin/env python3
"""Restore a previously saved 7F backup with patch-hash verification."""
from pathlib import Path
import argparse,hashlib,json,os,tempfile,sys

def sha(b):return hashlib.sha256(b.replace(b'\r\n',b'\n').removeprefix(b'\xef\xbb\xbf')).hexdigest()

def main():
 p=argparse.ArgumentParser(description='Safely roll back Soulfire 7F patch')
 p.add_argument('backup',type=Path,help='_Soulfire7F_backup_YYYYMMDD_HHMMSS directory')
 p.add_argument('--restore',action='store_true',help='Write rollback (default verify only)')
 args=p.parse_args()
 backup=args.backup.expanduser().resolve()
 data=json.loads((backup/'BACKUP_MANIFEST.json').read_text('utf-8'))
 project=Path(data['project']); problems=[]
 for e in data['manifest']:
  rel=Path(e['path']); now=project/rel
  if not now.is_file() or sha(now.read_bytes())!=e['replacement_sha256']:
   problems.append(str(rel))
  if e['mode']=='replace' and (not (backup/rel).is_file() or sha((backup/rel).read_bytes())!=e['source_sha256']):
   problems.append('backup corrupt '+str(rel))
 if problems:
  print('中止：下列文件在补丁应用后有进一步修改，避免覆盖用户工作。')
  print('\n'.join(problems));return 2
 print('回滚校验通过，目标：',project)
 if not args.restore:
  print('如需真正回滚，请增加 --restore');return 0
 for e in data['manifest']:
  rel=Path(e['path']);dest=project/rel
  if e['mode']=='new':dest.unlink()
  else:
   fd,tmp=tempfile.mkstemp(prefix='.rollback_',dir=str(dest.parent))
   with os.fdopen(fd,'wb') as f:f.write((backup/rel).read_bytes())
   os.replace(tmp,dest)
 print('已恢复原始文件。该操作只还原本补丁涉及的 6 个文件。');return 0

if __name__=='__main__':sys.exit(main())
