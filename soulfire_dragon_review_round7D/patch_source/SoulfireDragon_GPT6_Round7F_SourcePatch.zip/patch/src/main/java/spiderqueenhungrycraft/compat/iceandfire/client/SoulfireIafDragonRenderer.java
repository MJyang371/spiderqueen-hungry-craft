package spiderqueenhungrycraft.compat.iceandfire.client;

import com.mojang.blaze3d.vertex.PoseStack;

import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import spiderqueenhungrycraft.client.renderer.SoulfireDragonRenderer;
import spiderqueenhungrycraft.soulfire.SoulfireDragonEntity;

/**
 * Actual I&F fire-dragon skeleton geometry and poses, driven ONLY by the custom
 * HungryCraft entity state. Absolutely no EntityDragonBase / I&F dragon AI.
 *
 * On a missing jar resource we log a precise failure and draw the old model as
 * an obvious diagnostic fallback; it MUST NOT be accepted as successful I&F art.
 */
@OnlyIn(Dist.CLIENT)
public final class SoulfireIafDragonRenderer extends MobRenderer<SoulfireDragonEntity, SoulfireIafTabulaModel>
{
    private final SoulfireDragonRenderer failureFallback;

    public SoulfireIafDragonRenderer(EntityRendererProvider.Context context)
    {
        super(context, new SoulfireIafTabulaModel(), 0.9F);
        this.failureFallback = new SoulfireDragonRenderer(context);
    }

    @Override
    protected void scale(SoulfireDragonEntity entity, PoseStack stack, float partialTicks)
    {
        // Visually scale the same I&F geometry, not a new model.
        // Stage factors are deliberately centralized for test-world tuning.
        float factor = switch (entity.getStage())
        {
            case 1 -> 0.9F;
            case 2 -> 1.8F;
            case 3 -> 3.0F;
            case 4 -> 4.5F;
            default -> 6.0F;
        };
        stack.scale(factor, factor, factor);
        this.shadowRadius = 0.3F + factor * 0.18F;
    }

    @Override
    public ResourceLocation getTextureLocation(SoulfireDragonEntity entity)
    {
        int stage = Math.max(1, Math.min(5, entity.getStage()));
        return new ResourceLocation("iceandfire",
                "textures/models/firedragon/fire_skeleton_" + stage + ".png");
    }

    @Override
    public void render(SoulfireDragonEntity entity, float yaw, float partialTicks,
            PoseStack poseStack, MultiBufferSource buffers, int packedLight)
    {
        if (!this.model.ensureLoaded())
        {
            this.failureFallback.render(entity, yaw, partialTicks, poseStack, buffers, packedLight);
            return;
        }
        super.render(entity, yaw, partialTicks, poseStack, buffers, packedLight);
    }
}
