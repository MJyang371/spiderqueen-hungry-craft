package spiderqueenhungrycraft.compat.iceandfire.client;

import java.util.Collections;

import com.github.alexthe666.citadel.client.model.AdvancedEntityModel;
import com.github.alexthe666.citadel.client.model.AdvancedModelBox;
import com.github.alexthe666.citadel.client.model.TabulaModel;
import com.github.alexthe666.citadel.client.model.basic.BasicModelPart;
import com.github.alexthe666.iceandfire.client.model.util.TabulaModelHandlerHelper;

import spiderqueenhungrycraft.SpiderQueenHungryCraft;
import spiderqueenhungrycraft.soulfire.SoulfireDragonEntity;

/**
 * Stable MobRenderer model type which lazily delegates all geometry to the real
 * Ice and Fire fire-dragon Tabula skeleton model.
 *
 * Never bakes Tabula in the EntityRenderersEvent renderer constructor: the old
 * implementation did that too early and broke shader initialization.
 *
 * The source file belongs to HungryCraft. Models/texture/poses stay in I&F's jar.
 */
public final class SoulfireIafTabulaModel extends AdvancedEntityModel<SoulfireDragonEntity>
{
    // Exact same lower-case resource as IafClientSetup, including required .tbl.
    private static final String PATH = "/assets/iceandfire/models/tabula/firedragon/firedragon_ground.tbl";

    private TabulaModel delegate;
    private boolean attempted;

    public boolean ensureLoaded()
    {
        if (!this.attempted)
        {
            this.attempted = true;
            try
            {
                // A static Tabula geometry without its original animation library
                // is not a successful I&F animation integration.
                if (com.github.alexthe666.iceandfire.client.model.util.DragonAnimationsLibrary.getModel(
                        com.github.alexthe666.iceandfire.client.model.util.EnumDragonPoses.GROUND_POSE,
                        com.github.alexthe666.iceandfire.client.model.util.EnumDragonModelTypes.FIRE_DRAGON_MODEL) == null
                        || com.github.alexthe666.iceandfire.client.model.util.DragonAnimationsLibrary.getModel(
                        com.github.alexthe666.iceandfire.client.model.util.EnumDragonPoses.FLIGHT1,
                        com.github.alexthe666.iceandfire.client.model.util.EnumDragonModelTypes.FIRE_DRAGON_MODEL) == null)
                {
                    throw new IllegalStateException("I&F GROUND/FLIGHT pose library not ready");
                }
                this.delegate = new TabulaModel(
                        TabulaModelHandlerHelper.loadTabulaModel(PATH), new SoulfireDragonAnimator());
                if (this.delegate == null || !this.delegate.getAllParts().iterator().hasNext())
                {
                    throw new IllegalStateException("I&F Tabula skeleton has no model parts");
                }
                SpiderQueenHungryCraft.LOGGER.info(
                        "[Soulfire7F] REAL I&F bone-dragon Tabula model loaded: {}", PATH);
            }
            catch (Exception e)
            {
                SpiderQueenHungryCraft.LOGGER.error(
                        "[Soulfire7F] FAILED to load real I&F skeleton: {}. "
                                + "7D fallback is displayed ONLY AS A FAILURE INDICATOR.", PATH, e);
                this.delegate = null;
            }
        }
        return this.delegate != null;
    }

    @Override
    public void setupAnim(SoulfireDragonEntity entity, float limbSwing, float limbSwingAmount,
            float ageInTicks, float netHeadYaw, float headPitch)
    {
        if (this.delegate != null)
        {
            this.delegate.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
        }
    }

    @Override
    public Iterable<BasicModelPart> parts()
    {
        return this.delegate == null ? Collections.emptyList() : this.delegate.parts();
    }

    @Override
    public Iterable<AdvancedModelBox> getAllParts()
    {
        return this.delegate == null ? Collections.emptyList() : this.delegate.getAllParts();
    }
}
