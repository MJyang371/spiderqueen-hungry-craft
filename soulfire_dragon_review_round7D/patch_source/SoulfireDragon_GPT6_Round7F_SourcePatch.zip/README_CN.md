# Soulfire Dragon — GPT-6 7F 直接源码补丁（试验版）

> **性质：源码层替换补丁，并不是已经编译好的 Forge mod jar。**
> **基线：用户上传的 `soulfire_dragon_review_round7D.zip`，其中实际包含 `ROUND7E_STAGE_A_B.md` 版本。**
> GitHub `main` 未能在生成环境中取得完整源码，因此没有验证它是否和此 ZIP 一致。
> 基于这个原因，安装器对三个已存在的源文件做 SHA-256 校验，不一致即拒绝修改。

## 本次直接修复

**原版 I&F 骨龙模型与动画**

- 保留 `SoulfireDragonEntity`、自研 AI、移动、吐息、契约系统；不恢复 `EntityDragonBase`。
- 当 I&F + Citadel 存在，使用新客户端适配器 `SoulfireIafTabulaModel`：首次渲染时用官方的 `TabulaModelHandlerHelper` 加载准确的 `firedragon_ground.tbl`，以及官方 `DragonAnimationsLibrary` 提供的地面/行走/飞行姿态。
- 通过 `SoulfireIafDragonRenderer` 使用 I&F 原生的 `fire_skeleton_1..5.png`。火、冰、电遗骸仍统一显示同一种骨龙。
- 避免在 renderer **构造器**里过早加载 `.tbl`（7C 的 shader 崩溃来源）；改成进入世界的第一次渲染才加载。
- 找不到原生模型/动画时报告 `ERROR [Soulfire7F] FAILED`，才画 7D 占位模型。**出现占位模型即视为验收失败，不可报告成功。**
- 没有 I&F 时仍注册 7D 占位渲染器，不提前加载任何 I&F 客户端类。

**降落闭环**

- 高空落地不再只向下找 4 格，也不再把空中目标直接当作降落目标。
- 从真实高度向下搜索至多 192 格，横向半径 4 格，要求有实体 AABB 大小的空间以及可靠的承载地面，且不主动加载区块。
- 设置 landing 后不再每 tick 覆盖目标；接近地面时给出受控负向速度，触地后清空 flying/hovering/landing、恢复重力并阻尼移动速度。
- LANDING 超过 180 tick 未结束时记录警告、取消旧目标并重新寻找安全落点；无可用落点时维持悬停（而非假称已降落），并将搜索频率限至每 40 tick。
- 保存/重载不保留“没有目标的 LANDING”死锁，恢复时让 Goal 重新寻找落点。
- HOLD 只有实际 `onGround()` 才会收翼蹲伏，更新原先在空中记录的错误锚点。

## 文件表

| 文件 | 操作 |
|---|---|
| `soulfire/SoulfireDragonEntity.java` | 替换：LANDING 超时、落地状态与读档恢复 |
| `soulfire/goal/SoulfireCommandGoal.java` | 替换：真实地面搜索 + 空中任务降落 |
| `client/HungryCraftClientSetup.java` | 替换：I&F 存在时切换原生 Tabula 渲染器 |
| `compat/iceandfire/client/SoulfireDragonAnimator.java` | 新增：复用既有 7C 动画适配代码 |
| `compat/iceandfire/client/SoulfireIafTabulaModel.java` | 新增：安全、惰性的模型委托 |
| `compat/iceandfire/client/SoulfireIafDragonRenderer.java` | 新增：骨龙渲染器 |

表里的相对路径均指向 `src/main/java/spiderqueenhungrycraft/` 下。

## 安装（建议先让 DS 在源码副本上做）

1. **停止正在运行的 Minecraft / Gradle 游戏任务**，备份测试世界。
2. 解压本 ZIP 到项目目录之外，例如 `D:\MinecraftModding\_patches\Soulfire7F`。
3. 进入解压目录（Windows PowerShell）：

```powershell
py -3 .\apply_patch.py "D:\MinecraftModding\你的HungryCraft工程目录"
```

这是校验，不写入。确认显示 `OK` 后：

```powershell
py -3 .\apply_patch.py "D:\MinecraftModding\你的HungryCraft工程目录" --apply
```

程序会把三份原始文件备份到 **项目根目录的同级目录** `_Soulfire7F_backup_日期_时间`，再复制六个文件。不会使用 `git reset/clean/commit/add/stash`。

**源文件哈希不匹配时必然中止**：说明 DS 在 ZIP 版本之后又改过代码，不能强行复制，需要让 DS 检查 diff 再手工移植。

4. 在原工程运行（DS 负责核实环境、构建任务）：

```powershell
.\gradlew.bat compileJava
.\gradlew.bat runGameTestServer
```

5. 编译、GameTest 成功后，部署新构建 jar 至测试实例，进入游戏人工验证。**不要复制源码 ZIP 到 `mods`，它不是 mod jar。**

## 实机测试最小闭环

1. 生成灵火龙；首先看**外形是不是 I&F 原生骨龙**，而非长方形翼膜。如果仍是旧模型，查看 `latest.log` 中 `[Soulfire7F] FAILED` 的完整堆栈。
2. 在开阔地执行远距 MOVE（例如 50–90 格）；确认直线飞行。
3. 在约 15–25 格高度发 HOLD 或移动至短距离目标；确认真正接触地面，翅膀收起，不再长期悬空。
4. 从空中执行 FOLLOW，接近主人之后下落。
5. 在有屋顶/树木处测试，有安全空间时降落，没有时明确打印而非假称落地。
6. 空中保存并重进世界，执行 HOLD；确认任务能重新寻找到地面。
7. 检查不带 I&F 的启动不会加载 Tabula 类。

请 DS 的日志和报告特别区分：“渲染器被选中”“模型真正加载”“动画实际播放”“玩家看到原版骨架”。

## 诚实的验证范围

- **已做：** 从用户上传的实际 Java 源文件构造六个文件的替换包；逐文件源内容 SHA 校验；补丁安装与回滚脚本安全检查；Java 结构性检查。
- **未做：** Forge/Gradle 真正的 `compileJava`、GameTest、Minecraft 客户端启动、I&F 模型/动画实机截图。上传 ZIP 不包含完整工程、构建缓存与 I&F/Citadel 依赖，这个运行环境也没有联网编译能力，故不能声称“已通过”。
- **尚未处理：** 多段 hitbox、骑乘、灵魂火喷射的原版化、蓝色发光眼睛、其他契约边界。这一轮严格只修两个玩家阻断问题。
- **实体尺寸：** 本轮复用视觉模型后 stage 采用待调的渲染缩放系数；主碰撞盒仍维持旧版，必须在后续多段碰撞改造时同步校准，不要把视觉比例认为已验证。

## 回滚

```powershell
py -3 .\rollback_patch.py "D:\MinecraftModding\_Soulfire7F_backup_实际时间戳"
py -3 .\rollback_patch.py "D:\MinecraftModding\_Soulfire7F_backup_实际时间戳" --restore
```

回滚脚本先检查六个目标文件**仍然是本补丁的哈希**，如 DS 修改过任何一份则拒绝覆盖，保护它新增的劳动成果。

官方接口出处：
- Ice and Fire `IafClientSetup` 的地面模型路径及动画初始化：`https://github.com/AlexModGuy/Ice_and_Fire/blob/1.20.1-2.1.13-beta-5/src/main/java/com/github/alexthe666/iceandfire/client/IafClientSetup.java`
- `DragonAnimationsLibrary`，提供注册的姿态：`https://github.com/AlexModGuy/Ice_and_Fire/blob/1.20.1-2.1.13-beta-5/src/main/java/com/github/alexthe666/iceandfire/client/model/util/DragonAnimationsLibrary.java`
- `TabulaModelHandlerHelper` 对 `.tbl` 的处理：`https://github.com/AlexModGuy/Ice_and_Fire/blob/1.20.1-2.1.13-beta-5/src/main/java/com/github/alexthe666/iceandfire/client/model/util/TabulaModelHandlerHelper.java`
