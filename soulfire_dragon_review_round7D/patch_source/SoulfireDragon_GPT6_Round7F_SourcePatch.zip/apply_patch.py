#!/usr/bin/env python3
"""Safe, manifest-verified Soulfire 7F overlay installer. Stdlib only."""
from pathlib import Path
import argparse, datetime, hashlib, json, os, shutil, sys, tempfile

HOME = Path(__file__).resolve().parent
MANIFEST = json.loads((HOME/'manifest.json').read_text(encoding='utf-8'))

def normalized_bytes(p: Path) -> bytes:
    return p.read_bytes().replace(b'\r\n',b'\n').removeprefix(b'\xef\xbb\xbf')

def sha(content: bytes) -> str:
    return hashlib.sha256(content).hexdigest()

def check_project(project: Path):
    errs=[]; verified=[]
    if not (project/'src/main/java/spiderqueenhungrycraft').is_dir():
        errs.append('未找到 HungryCraft Java 源码目录，可能项目路径不对。')
    for e in MANIFEST:
        rel=Path(e['path']); dest=project/rel
        patch=HOME/'patch'/rel
        if not patch.is_file() or sha(patch.read_bytes()) != e['replacement_sha256']:
            errs.append(f'补丁自身校验失败: {rel}')
            continue
        if e['mode']=='replace':
            if not dest.is_file():
                errs.append(f'源文件缺失: {rel}')
            elif sha(normalized_bytes(dest))!=e['source_sha256']:
                errs.append(f'源文件与 ROUND 7E ZIP 不一致，禁止覆盖: {rel}')
            else:
                verified.append(rel)
        elif dest.exists():
            errs.append(f'目标文件已经存在，不覆盖: {rel}')
        else:
            verified.append(rel)
    return errs,verified

def atomic_write(dest:Path, content:bytes):
    dest.parent.mkdir(parents=True,exist_ok=True)
    fd,tmp=tempfile.mkstemp(prefix='.soulfire7f_',dir=str(dest.parent))
    try:
        with os.fdopen(fd,'wb') as f:
            f.write(content)
        os.replace(tmp,dest)
    finally:
        if os.path.exists(tmp): os.remove(tmp)

def main():
    a=argparse.ArgumentParser(description='Apply Soulfire 7F source overlay safely; refuses divergent originals')
    a.add_argument('project',type=Path,help='HungryCraft PROJECT ROOT (contains src/main/java)')
    a.add_argument('--apply',action='store_true',help='Actually write files; without this only check')
    opts=a.parse_args()
    project=opts.project.expanduser().resolve()
    problems, verified=check_project(project)
    for issue in problems: print('ERROR:',issue)
    if problems:
        print(f'中止：{len(problems)} 个不匹配。不要使用强制覆盖，请让 DS 对照 diff 合并。')
        return 2
    print(f'OK: 已校验 {len(verified)} 个补丁目标，源文件与 ROUND 7E 基线一致。')
    if not opts.apply:
        print('这是 dry-run；如需真正应用，增加 --apply 参数。')
        return 0
    parent=project.parent
    backup=parent/('_Soulfire7F_backup_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S'))
    backup.mkdir(parents=False,exist_ok=False)
    backed=[]
    try:
        for e in MANIFEST:
            if e['mode']!='replace': continue
            rel=Path(e['path']); dest=project/rel; target=backup/rel
            target.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(dest,target)
            backed.append(str(rel))
        bm={'project':str(project),'timestamp':datetime.datetime.now().isoformat(),
            'manifest':MANIFEST,'backed_up':backed}
        (backup/'BACKUP_MANIFEST.json').write_text(json.dumps(bm,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
        # All originals have been backed up OUTSIDE THE PROJECT before ANY write.
        for e in MANIFEST:
            rel=Path(e['path']);atomic_write(project/rel,(HOME/'patch'/rel).read_bytes())
        print(f'成功：已安装 {len(MANIFEST)} 个文件。')
        print('项目外备份:',backup)
        print('下一步由 DS 执行 compileJava / runGameTestServer / 客户端实机测试。')
        return 0
    except Exception as ex:
        print('写入失败：',ex, file=sys.stderr)
        print('请勿继续运行游戏，备份位置：',backup,file=sys.stderr)
        return 3

if __name__=='__main__': sys.exit(main())
