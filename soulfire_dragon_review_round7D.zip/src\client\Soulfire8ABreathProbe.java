package spiderqueenhungrycraft.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.Screenshot;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.monster.Husk;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import spiderqueenhungrycraft.SpiderQueenHungryCraft;
import spiderqueenhungrycraft.brood.SpiderOrderMode;
import spiderqueenhungrycraft.registry.HungryCraftEntities;
import spiderqueenhungrycraft.soulfire.SoulfireDragonEntity;

/**
 * The round 8A breath probe: how a soul fire dragon is supposed to breathe on the ground, the wall it must not breathe
 * through, the friends it must not burn, and the air bombardment that must not regress.
 *
 * <ol>
 * <li><b>Standing:</b> a nearby point is burnt in place, and the animal never leaves the floor for it.</li>
 * <li><b>Walking:</b> a point at the edge of the walk range is burnt WHILE the animal advances toward it.</li>
 * <li><b>The neck:</b> a point beside the animal is burnt with the head turned to the side, feet planted.</li>
 * <li><b>The wall:</b> a victim behind solid stone takes nothing.</li>
 * <li><b>The friends:</b> the queen and another unit of hers stand IN the stream and take nothing, while the stranger
 * behind them in the same stream does take damage.</li>
 * <li><b>The attack:</b> an ordinary ATTACK order at breath distance is answered on the ground, walking if need be.</li>
 * <li><b>The bombardment:</b> a far away point still takes off, exactly as it did before this round.</li>
 * </ol>
 *
 * <p>Switched on with {@code -Dspiderqueen.soulfire.breathProbe=true}; nothing happens without that switch.
 */
@OnlyIn(Dist.CLIENT)
@Mod.EventBusSubscriber(modid = SpiderQueenHungryCraft.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class Soulfire8ABreathProbe
{
    private static final boolean ENABLED = Boolean.getBoolean("spiderqueen.soulfire.breathProbe");

    /** When the course starts, in ticks after the world is up. */
    private static final int START_TICK = 100;

    private static int ticks;
    private static boolean started;
    private static boolean cleaned;
    private static boolean reported;

    private static SoulfireDragonEntity subject;
    private static ServerPlayer queen;
    private static int phase;
    private static int phaseTicks;

    // What one phase observed.
    private static boolean everFlew;
    private static int breathSamples;
    private static float maxSideHead;
    private static Vec3 walkStart;
    private static Husk victim;
    private static Husk farVictim;
    private static SoulfireDragonEntity friend;
    private static float victimHealth;
    private static float friendHealth;
    private static float queenHealth;
    private static Vec3 aimPoint;

    private Soulfire8ABreathProbe()
    {
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event)
    {
        if (!ENABLED || event.phase != TickEvent.Phase.END)
        {
            return;
        }

        Minecraft minecraft = Minecraft.getInstance();

        if (minecraft.isPaused())
        {
            if (minecraft.screen != null)
            {
                minecraft.setScreen(null);
            }

            return;
        }

        if (minecraft.getSingleplayerServer() == null || minecraft.player == null || minecraft.level == null)
        {
            return;
        }

        if (!started)
        {
            started = true;
            SpiderQueenHungryCraft.LOGGER.info("[round8a] breath probe: armed, the course starts in {} ticks",
                    START_TICK);
        }

        if (!cleaned)
        {
            cleaned = true;

            // A harness must not be paused by a missing window focus.
            minecraft.options.pauseOnLostFocus = false;

            ServerPlayer player = minecraft.getSingleplayerServer().getPlayerList().getPlayers().get(0);

            minecraft.getSingleplayerServer().getCommands().performPrefixedCommand(
                    player.createCommandSourceStack().withSuppressedOutput().withPermission(2),
                    "kill @e[type=spiderqueen_hungrycraft:soulfire_dragon]");
            SpiderQueenHungryCraft.LOGGER.info("[round8a] breath probe: the units of earlier runs were cleared out");
        }

        ticks++;

        if (ticks < START_TICK)
        {
            return;
        }

        if (ticks == START_TICK)
        {
            begin(minecraft);
        }

        step(minecraft);
    }

    /** One adult unit on the floor in front of the queen, holding its post, with a contract of its own. */
    private static void begin(Minecraft minecraft)
    {
        ServerLevel level = minecraft.getSingleplayerServer().overworld();
        queen = minecraft.getSingleplayerServer().getPlayerList().getPlayers().get(0);

        SoulfireDragonEntity dragon = HungryCraftEntities.SOULFIRE_DRAGON.get().create(level);

        if (dragon == null)
        {
            SpiderQueenHungryCraft.LOGGER.error("[round8a] breath probe: FAILED - the subject could not be built");

            return;
        }

        Vec3 where = queen.position();
        BlockPos post = BlockPos.containing(where.x + 8.0D, where.y, where.z);
        // The animal must STAND on the floor for a ground test: a subject spawned in the air is not a ground case at all,
        // and a harness that forgets this turns its own mistake into a product failure.
        BlockPos onTheFloor = level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING, post);
        dragon.moveTo(onTheFloor.getX() + 0.5D, onTheFloor.getY(), onTheFloor.getZ() + 0.5D, 0.0F, 0.0F);
        level.addFreshEntity(dragon);
        dragon.beginContract(queen.getUUID(), level.getGameTime() + 60000L);
        dragon.setOrderMode(SpiderOrderMode.HOLD);
        dragon.setAnchor(onTheFloor);
        dragon.setStage(4);
        dragon.setInvulnerable(true);
        subject = dragon;
        phase = 1;
        phaseTicks = 0;

        SpiderQueenHungryCraft.LOGGER.info(
                "[round8a] breath probe: the subject holds its post at {} (asked from {}) , onGround {} , the queen stands "
                        + "at {}",
                onTheFloor, post, dragon.onGround(), queen.blockPosition());
    }

    private static void step(Minecraft minecraft)
    {
        if (subject == null || subject.isRemoved())
        {
            return;
        }

        phaseTicks++;

        switch (phase)
        {
            case 1 -> standingPhase(minecraft);
            case 2 -> walkingPhase(minecraft);
            case 3 -> neckPhase(minecraft);
            case 4 -> wallPhase(minecraft);
            case 5 -> friendPhase(minecraft);
            case 6 -> attackPhase(minecraft);
            case 7 -> bombardPhase(minecraft);
            default -> finishOnce();
        }
    }

    private static void resetObservations()
    {
        everFlew = false;
        breathSamples = 0;
        maxSideHead = 0.0F;
        walkStart = subject.position();

        // Printed on purpose: a ground phase that begins in the air is a harness mistake, not a finding about the animal.
        SpiderQueenHungryCraft.LOGGER.info(
                "[round8a] breath probe: phase {} begins with the subject at {} , onGround={} flying={} hovering={}",
                phase, subject.blockPosition(), subject.onGround(), subject.isFlying(), subject.isHovering());
    }

    /** Watches the two things every ground phase must not do: leave the floor, and stop breathing. */
    private static void observe()
    {
        everFlew = everFlew || subject.isFlying() || subject.isHovering();
        breathSamples += subject.isBreathing() ? 1 : 0;
        maxSideHead = Math.max(maxSideHead, Math.abs(subject.syncedHeadYaw()));
    }

    /** @return a point in front of the unit (+Z) on the muzzle's own height, that many blocks away. */
    private static Vec3 aheadOfSubject(double distance)
    {
        Vec3 muzzle = subject.getMuzzlePosition();

        return new Vec3(muzzle.x, muzzle.y, muzzle.z + distance);
    }

    /** @return a point beside the unit (+X) on the muzzle's own height, that many blocks away. */
    private static Vec3 besideSubject(double distance)
    {
        Vec3 muzzle = subject.getMuzzlePosition();

        return new Vec3(muzzle.x + distance, muzzle.y, muzzle.z);
    }

    /** One: a nearby point, burnt while standing still. */
    private static void standingPhase(Minecraft minecraft)
    {
        if (phaseTicks == 1)
        {
            resetObservations();
            aimPoint = aheadOfSubject(10.0D);
            subject.breatheAt(BlockPos.containing(aimPoint));
            SpiderQueenHungryCraft.LOGGER.info("[round8a] breath probe: a point {} blocks ahead is to be burnt in place",
                    10);
        }

        watch(minecraft, 12.0D, 4.0D);
        observe();

        if (phaseTicks % 20 == 0)
        {
            shoot(minecraft, "8a_standing_" + phaseTicks);
        }

        if (phaseTicks == 60)
        {
            double drift = subject.position().distanceTo(walkStart);
            boolean ok = breathSamples >= 30 && !everFlew && drift < 2.0D;

            SpiderQueenHungryCraft.LOGGER.info(
                    "[round8a] breath probe: {} - standing breath: {} breathing ticks, left the floor {} , drifted {} "
                            + "blocks from its post",
                    ok ? "PASS" : "FAILED", breathSamples, everFlew, Math.round(drift * 100.0D) / 100.0D);
            phase++;
            phaseTicks = 0;
        }
    }

    /** Two: a point at the edge of the walk range, burnt WHILE the animal advances. */
    private static void walkingPhase(Minecraft minecraft)
    {
        if (phaseTicks == 1)
        {
            resetObservations();
            aimPoint = aheadOfSubject(20.0D);
            subject.breatheAt(BlockPos.containing(aimPoint));
            SpiderQueenHungryCraft.LOGGER.info(
                    "[round8a] breath probe: a point {} blocks ahead is to be burnt while walking", 20);
        }

        watch(minecraft, 14.0D, 5.0D);
        observe();

        if (phaseTicks % 30 == 0)
        {
            shoot(minecraft, "8a_walking_" + phaseTicks);
        }

        if (phaseTicks == 110)
        {
            double moved = walkStart.distanceTo(subject.position());
            boolean ok = breathSamples >= 60 && !everFlew && moved > 3.0D;

            SpiderQueenHungryCraft.LOGGER.info(
                    "[round8a] breath probe: {} - walking breath: {} breathing ticks, left the floor {} , advanced {} "
                            + "blocks while the stream ran",
                    ok ? "PASS" : "FAILED", breathSamples, everFlew, Math.round(moved * 100.0D) / 100.0D);
            phase++;
            phaseTicks = 0;
        }
    }

    /** Three: a point beside the animal, burnt with the neck turned and the feet planted. */
    private static void neckPhase(Minecraft minecraft)
    {
        if (phaseTicks == 1)
        {
            resetObservations();
            aimPoint = besideSubject(8.0D);
            subject.breatheAt(BlockPos.containing(aimPoint));
            SpiderQueenHungryCraft.LOGGER.info(
                    "[round8a] breath probe: a point 8 blocks to the SIDE is to be burnt without turning the body");
        }

        watch(minecraft, 10.0D, 3.0D);
        observe();

        if (phaseTicks % 25 == 0)
        {
            shoot(minecraft, "8a_neck_" + phaseTicks);
        }

        if (phaseTicks == 70)
        {
            boolean ok = breathSamples >= 35 && !everFlew && maxSideHead > 25.0F;

            SpiderQueenHungryCraft.LOGGER.info(
                    "[round8a] breath probe: {} - side breath: {} breathing ticks, left the floor {} , the head turned up "
                            + "to {} degrees off the body",
                    ok ? "PASS" : "FAILED", breathSamples, everFlew, Math.round(maxSideHead));
            phase++;
            phaseTicks = 0;
        }
    }

    /** Four: a victim behind solid stone takes nothing, over a stream that really does run for a while. */
    private static void wallPhase(Minecraft minecraft)
    {
        if (phaseTicks == 1)
        {
            resetObservations();
            ServerLevel level = minecraft.getSingleplayerServer().overworld();
            Vec3 muzzle = subject.getMuzzlePosition();
            int x = Mth.floor(muzzle.x);
            int z = Mth.floor(muzzle.z);

            victim = EntityType.HUSK.create(level);

            if (victim != null)
            {
                victim.moveTo(x + 0.5D, muzzle.y - 1.0D, z + 12.5D, 0.0F, 0.0F);
                victim.setNoAi(true);
                level.addFreshEntity(victim);
                victimHealth = victim.getHealth();
            }

            // A wall that certainly covers the line: five wide, and from one below the victim's feet to three above the
            // muzzle.
            int wallZ = z + 6;

            for (int dx = -2; dx <= 2; dx++)
            {
                for (int dy = -1; dy <= 3; dy++)
                {
                    level.setBlockAndUpdate(new BlockPos(x + dx, Mth.floor(muzzle.y) + dy, wallZ),
                            Blocks.STONE.defaultBlockState());
                }
            }

            aimPoint = new Vec3(x + 0.5D, muzzle.y - 0.5D, z + 12.5D);
            subject.breatheAt(BlockPos.containing(aimPoint));

            SpiderQueenHungryCraft.LOGGER.info(
                    "[round8a] breath probe: a stone wall stands 6 blocks ahead, a husk stands 12 blocks ahead with {} "
                            + "health, and the stream must stop at the wall",
                    victim == null ? -1.0F : victimHealth);
        }

        watch(minecraft, 12.0D, 4.0D);
        observe();

        if (phaseTicks % 30 == 0)
        {
            shoot(minecraft, "8a_wall_" + phaseTicks);
        }

        if (phaseTicks == 90)
        {
            float now = victim == null ? -1.0F : victim.getHealth();
            boolean ok = victim != null && Math.abs(now - victimHealth) < 0.001F && breathSamples >= 40;

            SpiderQueenHungryCraft.LOGGER.info(
                    "[round8a] breath probe: {} - a victim behind the wall: {} breathing ticks, the husk went {} -> {}",
                    ok ? "PASS" : "FAILED", breathSamples, victimHealth, now);
            phase++;
            phaseTicks = 0;
        }
    }

    /**
     * Five: the queen and another unit of hers stand in the stream and take nothing, while a stranger further along the
     * very same stream does take damage - the positive control that proves the stream was really there.
     */
    private static void friendPhase(Minecraft minecraft)
    {
        if (phaseTicks == 1)
        {
            resetObservations();
            ServerLevel level = minecraft.getSingleplayerServer().overworld();
            Vec3 muzzle = subject.getMuzzlePosition();
            int x = Mth.floor(muzzle.x);
            int z = Mth.floor(muzzle.z);
            int ground = Mth.floor(muzzle.y) - 1;

            // The corridor of this phase is cleared first, so the result is never decided by a random plant.
            clearPath(level, x, ground, z, 20);

            friend = HungryCraftEntities.SOULFIRE_DRAGON.get().create(level);

            if (friend != null)
            {
                friend.moveTo(x + 0.5D, ground, z + 10.5D, 0.0F, 0.0F);
                friend.setStage(2);
                friend.setNoAi(true);
                level.addFreshEntity(friend);
                friendHealth = friend.getHealth();
            }

            victim = EntityType.HUSK.create(level);

            if (victim != null)
            {
                victim.moveTo(x + 0.5D, ground, z + 16.5D, 0.0F, 0.0F);
                victim.setNoAi(true);
                level.addFreshEntity(victim);
                victimHealth = victim.getHealth();
            }

            // The queen stands in the stream herself, five blocks in front of the jaws.
            placeQueen(minecraft, new Vec3(x + 0.5D, ground, z + 5.5D), subject.position());
            queenHealth = queen.getHealth();

            subject.breatheAt(BlockPos.containing(x + 0.5D, ground + 1.0D, z + 16.5D));

            SpiderQueenHungryCraft.LOGGER.info(
                    "[round8a] breath probe: the queen ({} health) and a unit of hers ({} health) stand IN the stream, and a "
                            + "stranger ({} health) stands at its far end",
                    queenHealth, friend == null ? -1.0F : friendHealth, victim == null ? -1.0F : victimHealth);
        }

        observe();

        if (phaseTicks % 30 == 0)
        {
            shoot(minecraft, "8a_friends_" + phaseTicks);
        }

        if (phaseTicks == 120)
        {
            float queenNow = queen.getHealth();
            float friendNow = friend == null ? -1.0F : friend.getHealth();
            float victimNow = victim == null ? -1.0F : victim.getHealth();
            boolean strangerHurt = victim != null && victimNow < victimHealth - 0.001F;
            boolean attributed = victim != null && victim.getLastHurtByMob() == subject;
            boolean friendsSafe = Math.abs(queenNow - queenHealth) < 0.001F
                    && friend != null && Math.abs(friendNow - friendHealth) < 0.001F
                    && friend.getRemainingFireTicks() == 0;

            SpiderQueenHungryCraft.LOGGER.info(
                    "[round8a] breath probe: {} - one stream: the queen {} -> {} , a unit of hers {} -> {} (fire {} ticks), "
                            + "the stranger {} -> {} ({}) , and the damage is remembered as the dragon's: {}",
                    friendsSafe && strangerHurt && attributed ? "PASS" : "FAILED", queenHealth, queenNow, friendHealth,
                    friendNow, friend == null ? -1 : friend.getRemainingFireTicks(), victimHealth, victimNow,
                    strangerHurt ? "the stream was really there" : "the stream hit nothing, so nothing was proven",
                    attributed);
            phase++;
            phaseTicks = 0;
        }
    }

    /** Clears a small corridor so the stream of one phase is never decided by a random plant. */
    private static void clearPath(ServerLevel level, int x, int ground, int z, int length)
    {
        for (int dx = -3; dx <= 3; dx++)
        {
            for (int dz = 0; dz <= length; dz++)
            {
                for (int dy = 0; dy <= 4; dy++)
                {
                    BlockPos p = new BlockPos(x + dx, ground + dy, z + dz);

                    if (!level.getBlockState(p).isAir())
                    {
                        level.setBlockAndUpdate(p, Blocks.AIR.defaultBlockState());
                    }
                }
            }
        }
    }

    /** Six: an ordinary ATTACK order at breath distance, answered on the ground - walking if it has to. */
    private static void attackPhase(Minecraft minecraft)
    {
        if (phaseTicks == 1)
        {
            resetObservations();
            ServerLevel level = minecraft.getSingleplayerServer().overworld();
            Vec3 muzzle = subject.getMuzzlePosition();
            int x = Mth.floor(muzzle.x);
            int z = Mth.floor(muzzle.z);
            int ground = Mth.floor(muzzle.y) - 1;

            clearPath(level, x, ground, z, 24);

            farVictim = EntityType.HUSK.create(level);

            if (farVictim != null)
            {
                farVictim.moveTo(x + 0.5D, ground, z + 19.5D, 0.0F, 0.0F);
                farVictim.setNoAi(true);
                // Immortal on purpose: this phase measures what the animal does, not what the victim loses.
                farVictim.setInvulnerable(true);
                level.addFreshEntity(farVictim);
            }

            subject.setForcedTarget(farVictim);
            SpiderQueenHungryCraft.LOGGER.info(
                    "[round8a] breath probe: an ordinary ATTACK order on a stranger {} blocks away; the animal must burn it "
                            + "without leaving the floor",
                    farVictim == null ? -1 : Math.round(subject.distanceTo(farVictim)));
        }

        watch(minecraft, 14.0D, 5.0D);
        observe();

        if (phaseTicks % 40 == 0)
        {
            shoot(minecraft, "8a_attack_" + phaseTicks);
        }

        if (phaseTicks == 160)
        {
            boolean ok = !everFlew && breathSamples >= 60;

            SpiderQueenHungryCraft.LOGGER.info(
                    "[round8a] breath probe: {} - the ground attack: {} breathing ticks and the floor was left {}",
                    ok ? "PASS" : "FAILED", breathSamples, everFlew);
            subject.setForcedTarget(null);
            phase++;
            phaseTicks = 0;
        }
    }

    /** Seven: a far away point still takes off, because the air bombardment is not part of this round. */
    private static void bombardPhase(Minecraft minecraft)
    {
        if (phaseTicks == 1)
        {
            resetObservations();
            aimPoint = aheadOfSubject(70.0D);
            subject.breatheAt(BlockPos.containing(aimPoint));
            SpiderQueenHungryCraft.LOGGER.info(
                    "[round8a] breath probe: a point {} blocks away is to be bombarded from the air, as before", 70);
        }

        watch(minecraft, 22.0D, 12.0D);
        observe();

        if (phaseTicks % 60 == 0)
        {
            shoot(minecraft, "8a_bombard_" + phaseTicks);
        }

        if (phaseTicks == 200)
        {
            boolean ok = everFlew && breathSamples >= 20;

            SpiderQueenHungryCraft.LOGGER.info(
                    "[round8a] breath probe: {} - the distant bombardment: {} breathing ticks and it took off {}",
                    ok ? "PASS" : "FAILED", breathSamples, everFlew);
            phase++;
            phaseTicks = 0;
        }
    }

    /** Puts the queen (and with her the camera) at that spot, looking at that point. */
    private static void placeQueen(Minecraft minecraft, Vec3 where, Vec3 aim)
    {
        double dx = aim.x - where.x;
        double dy = aim.y - where.y;
        double dz = aim.z - where.z;
        float yaw = (float) (Mth.atan2(dz, dx) * 180.0D / Math.PI) - 90.0F;
        float pitch = (float) (-(Mth.atan2(dy, Math.sqrt(dx * dx + dz * dz)) * 180.0D / Math.PI));

        queen.setNoGravity(true);
        queen.setInvulnerable(true);
        queen.getServer().getCommands().performPrefixedCommand(
                queen.createCommandSourceStack().withSuppressedOutput().withPermission(2),
                String.format(java.util.Locale.ROOT, "tp @s %.3f %.3f %.3f %.1f %.1f", where.x, where.y, where.z, yaw,
                        pitch));
        minecraft.player.setYRot(yaw);
        minecraft.player.setXRot(pitch);
    }

    /** Stands the camera beside the subject, in steps of five ticks, so the stream really shows in the frames. */
    private static void watch(Minecraft minecraft, double side, double up)
    {
        if (phaseTicks % 5 != 0)
        {
            return;
        }

        Vec3 look = subject.getLookAngle();
        Vec3 across = new Vec3(-look.z, 0.0D, look.x).normalize();
        Vec3 camera = subject.position().add(across.scale(side)).add(0.0D, up, 0.0D);
        Vec3 aim = subject.getMuzzlePosition();

        placeQueen(minecraft, camera, aim);
    }

    /** The ordinary screenshot of the game, into the shots folder of the instance. */
    private static void shoot(Minecraft minecraft, String name)
    {
        Screenshot.grab(minecraft.gameDirectory, "soulfire_" + name, minecraft.getMainRenderTarget(),
                component -> SpiderQueenHungryCraft.LOGGER.info("[round8a] breath probe: frame {} written ({})", name,
                        component.getString()));
    }

    /** Prints the closing line of the run once. */
    private static void finishOnce()
    {
        if (reported)
        {
            return;
        }

        reported = true;

        if (queen != null)
        {
            queen.setNoGravity(false);
            queen.setInvulnerable(false);
        }

        SpiderQueenHungryCraft.LOGGER.info(
                "[round8a] breath probe: the course is over - the frames are in the screenshots folder of the instance");
    }
}
