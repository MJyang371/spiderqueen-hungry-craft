package spiderqueenhungrycraft.soulfire;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * The SOUL fire beam used by both ground and air attacks.
 * Combat attribution, particles and obstruction all use the same server-authoritative dragon.
 * This class decides neither movement nor attack selection; the RTS command Goal owns that.
 */
public final class SoulfireBreath
{
    public static final int DAMAGE_INTERVAL = 5;
    public static final int SOUND_INTERVAL = 8;
    /** Deliberately bounded: long-lived groups of dragons must not emit 16 separate packets every tick each. */
    public static final int FLAMES_PER_TICK = 9;
    public static final double PARTICLE_SPEED = 0.28D;
    public static final double DAMAGE_PER_STAGE = 0.5D;
    public static final float BASE_DAMAGE = 1.0F;
    public static final int BURN_SECONDS = 5;
    private static final double CONE = 0.90D;
    private static final double HEAD_ROOM = 3.0D;
    private static final boolean DEBUG = Boolean.getBoolean("spiderqueen.soulfire.breathDebug");

    private SoulfireBreath() {}

    public static void tick(SoulfireDragonEntity dragon, Vec3 target)
    {
        if (!(dragon.level() instanceof ServerLevel level) || dragon.isDeadOrDying())
        {
            return;
        }
        Vec3 muzzle = dragon.getMuzzlePosition();
        Vec3 towards = target.subtract(muzzle);
        if (towards.lengthSqr() < 1.0E-6D)
        {
            return;
        }

        Vec3 aim = towards.normalize();
        dragon.setBreathing(true);
        // Existing neck/head animator follows the aim on land as well as in the air.
        dragon.getLookControl().setLookAt(target.x, target.y, target.z, 30.0F, 30.0F);

        // Stop visual flames at the first solid block. The same reach limits damage queries.
        Vec3 limit = muzzle.add(aim.scale(SoulfireDragonEntity.BREATH_RANGE));
        HitResult block = level.clip(new ClipContext(muzzle, limit,
                ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, dragon));
        double effectiveReach = block.getType() == HitResult.Type.BLOCK
                ? Math.max(0.0D, muzzle.distanceTo(block.getLocation()) - 0.08D)
                : SoulfireDragonEntity.BREATH_RANGE;

        if (effectiveReach > 0.1D)
        {
            spawnFlames(level, muzzle, aim, effectiveReach);
        }
        if (dragon.breathTicks() % SOUND_INTERVAL == 0)
        {
            level.playSound(null, dragon.getX(), dragon.getY(), dragon.getZ(), SoundEvents.BLAZE_SHOOT,
                    SoundSource.HOSTILE, 1.2F, 0.6F);
        }
        if (effectiveReach > 0.1D && dragon.breathTicks() % DAMAGE_INTERVAL == 0)
        {
            burn(level, dragon, muzzle, aim, effectiveReach);
        }
        dragon.advanceBreathTicks();
    }

    private static void spawnFlames(ServerLevel level, Vec3 muzzle, Vec3 aim, double reach)
    {
        // count=0 is Minecraft's single-particle path: the offset vector becomes its motion.
        // This intentionally differs from count>0, whose offsets would be randomized as a cloud.
        for (int flame = 0; flame < FLAMES_PER_TICK; flame++)
        {
            double along = reach * level.random.nextDouble();
            double spread = 0.10D + 0.025D * along;
            Vec3 origin = muzzle.add(aim.scale(along)).add(
                    (level.random.nextDouble() - 0.5D) * spread,
                    (level.random.nextDouble() - 0.5D) * spread,
                    (level.random.nextDouble() - 0.5D) * spread);
            double speed = PARTICLE_SPEED * (0.85D + level.random.nextDouble() * 0.3D);
            Vec3 velocity = aim.scale(speed);
            level.sendParticles(ParticleTypes.SOUL_FIRE_FLAME,
                    origin.x, origin.y, origin.z, 0, velocity.x, velocity.y, velocity.z, 1.0D);
        }
    }

    private static void burn(ServerLevel level, SoulfireDragonEntity dragon,
            Vec3 muzzle, Vec3 aim, double reach)
    {
        AABB search = new AABB(muzzle, muzzle.add(aim.scale(reach))).inflate(HEAD_ROOM);
        for (LivingEntity victim : level.getEntitiesOfClass(LivingEntity.class, search))
        {
            if (!SoulfireTargeting.isHuntable(dragon, victim))
            {
                continue;
            }
            Vec3 centre = victim.getBoundingBox().getCenter();
            Vec3 towardsVictim = centre.subtract(muzzle);
            double distance = towardsVictim.length();
            if (distance < 1.0E-4D || distance > reach + 0.25D
                    || towardsVictim.scale(1.0D / distance).dot(aim) < CONE)
            {
                continue;
            }
            // A cone is not permission to hit through buildings. Block collision is server-authoritative.
            HitResult cover = level.clip(new ClipContext(muzzle, centre,
                    ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, dragon));
            if (cover.getType() == HitResult.Type.BLOCK)
            {
                continue;
            }

            // IMPORTANT: this was already mobAttack(dragon) in 7H. The real problem is NOT
            // a missing owner in the DamageSource. A mob's decision to retaliate still depends
            // on its own target goals and on whether it accepted the damage.
            boolean accepted = victim.hurt(level.damageSources().mobAttack(dragon),
                    BASE_DAMAGE + (float) (DAMAGE_PER_STAGE * dragon.getStage()));
            if (accepted)
            {
                victim.setSecondsOnFire(BURN_SECONDS);
                if (DEBUG)
                {
                    spiderqueenhungrycraft.SpiderQueenHungryCraft.LOGGER.info(
                            "[Soulfire8A] BREATH_HIT dragon={} victim={} rememberedAttacker={} health={}",
                            dragon.getUUID(), victim.getUUID(),
                            victim.getLastHurtByMob() == dragon, victim.getHealth());
                }
            }
        }
    }
}
