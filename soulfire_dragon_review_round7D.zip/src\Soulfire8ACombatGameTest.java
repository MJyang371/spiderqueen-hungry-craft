package spiderqueenhungrycraft.soulfire;

import net.minecraft.core.BlockPos;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.monster.Husk;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.gametest.GameTestHolder;
import net.minecraftforge.gametest.PrefixGameTestTemplate;
import spiderqueenhungrycraft.SpiderQueenHungryCraft;
import spiderqueenhungrycraft.registry.HungryCraftEntities;

/** Tests factual damage attribution and the standing ability path, not a particular monster's AI. */
@GameTestHolder(SpiderQueenHungryCraft.MODID)
@PrefixGameTestTemplate(false)
public final class Soulfire8ACombatGameTest
{
    private Soulfire8ACombatGameTest() {}

    @GameTest(template = "humanspawn_flat", batch = "soulfire8a_combat", timeoutTicks = 100)
    public static void groundbreathcreditsdragon(GameTestHelper helper)
    {
        SoulfireDragonEntity dragon = helper.spawn(HungryCraftEntities.SOULFIRE_DRAGON.get(),
                new BlockPos(2, 1, 2));
        // Smaller stage to keep the whole ray inside the flat GameTest template.
        dragon.setStage(2);
        // The forward of yaw=0 is +Z.
        dragon.setYRot(0.0F);
        dragon.yBodyRot = 0.0F;
        Husk victim = helper.spawn(EntityType.HUSK, new BlockPos(2, 1, 8));
        victim.setNoAi(true);
        float health = victim.getHealth();
        Vec3 aim = victim.getBoundingBox().getCenter();
        SoulfireBreath.tick(dragon, aim);
        if (victim.getHealth() >= health)
        {
            helper.fail("soulfire beam did not damage the husk; inspect muzzle and ray obstruction");
            return;
        }
        if (victim.getLastHurtByMob() != dragon)
        {
            helper.fail("breath damage was not attributed to the dragon");
            return;
        }
        if (dragon.isFlying() || dragon.isHovering())
        {
            helper.fail("breath execution unexpectedly set a flying or hovering flag");
            return;
        }
        helper.succeed();
    }

    @GameTest(template = "humanspawn_flat", batch = "soulfire8a_combat", timeoutTicks = 100)
    public static void nearbygroundskilldoesnottakeoff(GameTestHelper helper)
    {
        SoulfireDragonEntity dragon = helper.spawn(HungryCraftEntities.SOULFIRE_DRAGON.get(),
                new BlockPos(2, 1, 2));
        dragon.setStage(2);
        dragon.setYRot(0.0F);
        dragon.yBodyRot = 0.0F;
        dragon.breatheAt(new BlockPos(2, 1, 8));
        final int[] time = {0};
        helper.onEachTick(() ->
        {
            if (++time[0] == 15)
            {
                if (!dragon.isBreathing() || dragon.isFlying() || dragon.isHovering())
                {
                    helper.fail("nearby ground breath took off or failed to execute: fly="
                            + dragon.isFlying() + " hover=" + dragon.isHovering()
                            + " breath=" + dragon.isBreathing());
                    return;
                }
                helper.succeed();
            }
        });
    }
}
