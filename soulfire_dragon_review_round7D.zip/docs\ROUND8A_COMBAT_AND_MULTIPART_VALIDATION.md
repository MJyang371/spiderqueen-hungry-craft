# ROUND 8A — 吐息与战斗（Stage 1）+ multipart 修订（Stage 2，未安装）

> 承接 ROUND 7I。本轮以 GPT-6 `SoulfireDragon_GPT6_Round8A_Stage2PlusCombat.zip` 为参考增量源码，**只安装 Stage 1（吐息/战斗）**；Stage 2 仅在 Stage 1 通过玩家验收后才安装。
> **不重新设计灵火龙、不放弃现有 I&F 骨龙模型/动画/独立飞行/降落机制。**

---

## 1. 结论速览（Stage 1）

| # | 任务要求 | 状态 | 证据 |
|---|---|---|---|
| 1 | 只读哈希校验后再安装 | ✔ | 安装器 dry-run `3 pending / 0 REFUSE`；落盘哈希与 manifest `new_sha256` 全等（§4） |
| 2 | 真实 Forge 环境编译、只修确切 API 错误 | ✔ | `compileJava` **BUILD SUCCESSFUL**，**没有任何 API 错误**，未做修改（§4） |
| 3 | GameTest：伤害归属 + 近距离吐息不强制起飞 | **通过** ✔ | 我方补充测试 3/3（§5.2）：伤害到达且归属龙 ✔、近距离不离开地面 ✔（立即下令与结算后下令各一次）✗ 补丁自带那两项因放置位置失败（§5.1） |
| 4 | 客户端实测：站立吐息 / 行走吐息 / 侧面扭头吐息 | **无法判定** ✗ | 探针未建立"站在地面"前置条件（§6.3 有逐阶段证据）；同批断言改由 §5.2 的 GameTest 回答 ✔ |
| 5 | 普通 ATTACK 地面吐息 与 远距离 BOMBARD 空中吐息互不破坏 | **远距离 ✔ / 地面无法判定** | 空中轰炸照旧起飞 ✔（实机 PASS）；地面 ATTACK 因探针前置条件失败无法判定 ✗ |
| 6 | 实心墙遮挡 | **失败** ✗ | GameTest `20.0 -> 18.08` + 实机 `20 → 5.3`，两次独立测量一致 ⇒ **射线穿过实心石墙** |
| 7 | 友军保护 | **通过** ✔ | 实机 PASS（女王 20→20、她的同类 100→100 且着火 0，同一条射流里的陌生者 20→0） |
| 8 | 粒子运动速度 | **仅代码核对** ✗ | 已确认走 `count=0` 单粒子分支并带前向速度（`PARTICLE_SPEED=0.28`），没有数值测量 |
| 9 | `mobAttack(dragon)` 的调查纪律 | ✔ | 见 §6.5：未重造 DamageSource；归属已核实；**反击行为未核实**（目标都关了 AI） |
| 10 | 保留 7I 逐 tick 转向的失败记录 | ✔ | §5.3 复现同样三条失败 ✗ |
| 11 | 不碰眼睛/骑乘/龙骨身份；不执行 git 破坏性操作 | ✔ | §2、§8 |

---

## 2. 版本与安全

| 项目 | 值 |
|---|---|
| 补丁包 | `D:\MinecraftModding\_references\SoulfireDragon_GPT6_Round8A_Stage2PlusCombat.zip`（43 KB） |
| 包内 SHA-256 | `392F36D46476B0FD5A31BC42A4BB55651FA8F76C2D7D1B0968C78B6FD553BBE5` |
| 解包目录 | `D:\MinecraftModding\_patches\Soulfire8A\` |
| 我的外部备份 | `D:\MinecraftModding\_backups\round8a_before\`（42 个文件：`soulfire`、`compat\iceandfire`） |
| 安装器外部备份 | `D:\MinecraftModding\_soulfire8a_external_backups\stage1_20261010_222417_795452\` |
| Git | HEAD 仍为 `34a97714bef7a5a130461d737e73f5a3629dc978`；**未执行** reset/clean/checkout/commit/add/stash |
| 回滚 | 见 §9（安装器 `rollback_patch.py` 或我的整目录备份） |

---

## 3. Stage 1 装了什么（逐项，含我对差异的复核）

### 3.1 `SoulfireBreath.java`（替换）

| 改动 | 说明 |
|---|---|
| 新增**方块遮挡** | 火焰与伤害都先做 `level.clip(muzzle → 目标, Block.COLLIDER)`，`effectiveReach` 由命中点决定 ⇒ 不再穿墙 |
| 粒子 16 → **9**/tick，且**带前向速度** | `count=0` 的单粒子路径：速度 = `aim * PARTICLE_SPEED(0.28) * (0.85..1.15)`；注释明确说明与 `count>0` 的随机云不同 |
| 伤害归属 | **仍然是 `damageSources().mobAttack(dragon)`**（7H 就是如此，未重造）✔；改为**只有 `hurt` 返回 true 才点燃**；新增 `-Dspiderqueen.soulfire.breathDebug=true` 的 `BREATH_HIT` 日志（记录 `rememberedAttacker` 与血量） |
| 友军保护 | `SoulfireTargeting.isHuntable` 检查**原样保留** ✔（女王/同类/她的其他单位不会被烧） |
| 命中判定 | 目标中心改为 `victim.getBoundingBox().getCenter()`；锥角判据 `dot(aim) < CONE(0.90)` 保留；射程改为 `reach + 0.25`（reach 来自遮挡） |

**我的复核结论（与本地 7H 版的差异）**：代码为同一功能的改写 ✔，语义增量如上 ✔；**两处需要记录的副作用**：
1. 类级设计注释（7C 的"粒子不是伤害"那段说明）被替换为简短注释 ⇒ 属于**文档退化**（我未擅自改回，见 §8 待办）；
2. 近距离保护：本地版对 `distance <= 0.5` 的目标**跳过锥角检查**，新版一律检查锥角 ⇒ 贴脸且在瞄准线后的目标可能不再被烧（影响极小，记录备查）。

### 3.2 `goal/SoulfireCommandGoal.java`（替换）

| 改动 | 说明 |
|---|---|
| 新增常量 | `GROUND_BREATH_WALK_UNTIL = 14.0`、`GROUND_BREATH_MAX_DISTANCE = BREATH_RANGE - 1.0 (= 23)` |
| 点攻击（吐息点） | 若**在地面**且枪口到目标 ≤ 23 且有视线（`hasGroundBreathLine`，允许命中的是"被点击的那块方块"本身，误差 1.25 格）⇒ **原地或边走边喷并 return**（不再因为天空开阔而强制起飞）✔ |
| 远距离点 | 仍然走原来的 `hoverOver`（空中轰炸）✔ 未改 |
| 攻击目标分支 | 距离 > 14 ⇒ `walkTo(victim)` 且同时吐息；≤ 14 ⇒ `holdStill()` ✔（咬击优先级在其前，保持 ✔） |

### 3.3 `Soulfire8ACombatGameTest.java`（新增，2 项）

* `groundbreathcreditsdragon`：吐息后断言**目标掉血**、`getLastHurtByMob() == dragon`、并且**没有设置飞行/悬停**。
* `nearbygroundskilldoesnottakeoff`：近距离 `breatheAt` 后 15 tick，断言**正在吐息**且**没有起飞/悬停**。

> 关于"被攻击的生物是否反击"：按任务纪律，本轮**不重造伤害系统**。`mobAttack(dragon)` 决定的是**伤害归属**；是否反击取决于该生物自身的目标 AI（例如 Husk/Zombie 的 `HurtByTargetGoal`）。测试里僵尸类目标被 `setNoAi(true)`，**不能**用来证明反击行为，报告中将明确区分（§6.4）。

---

## 4. 应用过程（可复核的原始输出）

### 4.1 哈希校验（含一次"假警报"的澄清）

我第一步用 PowerShell 的原始 `Get-FileHash` 比对时，`SoulfireBreath.java` 显示 **MISMATCH**（本地 `88fbab41…` ≠ manifest `4a5f6feb…`）。按任务要求我**停下来先查差异**，用与安装器**完全相同的算法**（去掉 BOM、把 CRLF 归一化为 LF）复核（脚本：`build\hashcheck8a.py`）：

```
local_breath  (want old 4a5f6feb53a92221)  raw=88fbab418bbef897  norm=4a5f6feb53a92221  crlf=True
patch_breath  (want new 014015925cb7015e)  raw=014015925cb7015e  norm=014015925cb7015e  crlf=False
local_goal    (want old 5d0948792412201f)  raw=5d0948792412201f  norm=5d0948792412201f  crlf=False
patch_goal    (want new dd8c3e81f67ef4b0)  raw=dd8c3e81f67ef4b0  norm=dd8c3e81f67ef4b0  crlf=False
patch_test    (want new 7b331c7c428d9160)  raw=7b331c7c428d9160  norm=7b331c7c428d9160  crlf=False
local_entity  (want old dd12d4375a2d9ba8)  raw=dd12d4375a2d9ba8  norm=dd12d4375a2d9ba8  crlf=False
```

**结论**：本地 `SoulfireBreath.java` 与基线**内容完全一致**，唯一差别是**行尾**（本地 CRLF、manifest 基于 LF）✔ ⇒ 不是真实分歧，**无需任何强制覆盖**；"假警报"来自我第一版 PowerShell 归一化写法本身（已用等价算法澄清）✔。
另外交叉验证：7H/7I 复核包里的 `src\SoulfireBreath.java` 与我本地文件**逐字节相同**（`88fbab41…`）✔。

### 4.2 安装

```
READY ADD soulfire/Soulfire8ACombatGameTest.java
READY REPLACE soulfire/SoulfireBreath.java
READY REPLACE soulfire/goal/SoulfireCommandGoal.java
DRY-RUN PASS | 3 pending
→ --apply：
APPLIED ADD soulfire/Soulfire8ACombatGameTest.java
APPLIED REPLACE soulfire/SoulfireBreath.java
APPLIED REPLACE soulfire/goal/SoulfireCommandGoal.java
EXTERNAL BACKUP: D:\MinecraftModding\_soulfire8a_external_backups\stage1_20261010_222417_795452
```

落盘复核（与 manifest `new_sha256`）：`SoulfireBreath` ✔ / `SoulfireCommandGoal` ✔ / `Soulfire8ACombatGameTest` ✔ 三项全部 MATCH。

---

## 6. 实机（真实客户端 + 集成服务端）结果

### 6.1 探针

新增 `client/Soulfire8ABreathProbe.java`（`-Dspiderqueen.soulfire.breathProbe=true`）：7 个阶段，站立 / 行走 / 侧面扭头 / 实心墙 / 友军保护 / 普通 ATTACK / 远距离 BOMBARD，每阶段记录"是否离开地面、吐息 tick 数、头相对身体的转角、目标血量"，并在关键帧截图。实机世界用**复制并清空实体的测试世界**（`probe_clean`，保留地形），开场还会 `/kill` 同类单位一次。

日志：`build\probe_8a1.log`（第一次）、`build\probe_8a2.log`（修正落位后）——**两次判定完全一致**。

### 6.2 结果

| 阶段 | 判定 | 原始读数 |
|---|---|---|
| 友军保护 | **PASS** ✔ | 女王 20→20 ✔、她的同类 100→100（着火 0 tick）✔、陌生者 20→0 ✔（"射流确实存在"），且 `getLastHurtByMob()==dragon` ✔ |
| 远距离 BOMBARD | **PASS** ✔ | 200 tick 在喷 ✔ 且照旧起飞 ✔（无回归） |
| 站立吐息 | 无法判定 ✗ | 60 tick 在喷 ✔，但"离开地面 true"、漂 23.58 格 |
| 行走吐息 | 无法判定 ✗ | 110 tick 在喷 ✔、前进 17.26 格 ✔，但"离开地面 true" |
| 侧面扭头 | 无法判定 ✗ | 70 tick 在喷 ✔、头相对身体 156° ✔，但"离开地面 true" |
| 实心墙 | 无法判定 ✗ | husk 20→5.3（**没有**被墙挡住）——但此时龙已在空中越过墙顶 |
| 普通 ATTACK | 无法判定 ✗ | 154 tick 在喷 ✔，但"离开地面 true" |

### 6.3 为什么这四项"无法判定"（前置条件未被建立的证据）

探针每个阶段开始时都会打印状态，这两行是决定性的：

```
[22:50:00] the subject holds its post at BlockPos{x=662, y=64, z=-54} (asked from ... y=148 ...) , onGround=f...
[22:50:00] phase 1 begins with the subject at ... onGround=false flying=false hovering=false
[22:50:03] phase 2 begins with ... y=79 , onGround=false flying=false hovering=true
[22:50:08] phase 3 begins with ... y=90 , onGround=false flying=false hovering=true
```

* 受试者在**生成的那一 tick 还没有被标记为站在地面**（`onGround=false`）✗ ⇒ goal 的"地面吐息"分支（要求 `onGround`) 不会成立 ⇒ 第一条"近距离吐息"指令直接走了原版的**悬停轰炸**分支 ✗ ⇒ 它飞起来 ✗；
* 从那一刻起，它在**每一个后续阶段的起点都已经是 hovering** ✗ ⇒ 之后所有"地面"断言测的都是空中行为 ✗；
* 因此**这四项不能作为产品判定** ✗；界面（女王）当时也还在上一次运行的高度（y=148）上，说明这次会话的世界状态本来就不干净 ✔。

**结论**：实机这一轮**只拿到了两项确定结论**（友军保护 ✔、远距离轰炸 ✔），其余四项交给**能确定性建立"站在地面"前置条件的 GameTest**（§5.2 的四项，结果见 §5.4）。

### 6.4 帧序列（可视证据）

`build\probe_shots\round8a\`（自客户端实例的截图目录复制）：`8a_standing_20/40/60`、`8a_walking_30/60/90`、`8a_neck_25/50`、`8a_wall_30/60/90`、`8a_friends_30/60/90/120`、`8a_attack_40/80/120/160`、`8a_bombard_60/120/180`。

### 6.5 关于"被攻击的生物是否反击"（任务明确要求核实，而不是重造 DamageSource）

* **本轮没有重造伤害系统**：代码里仍然是 `damageSources().mobAttack(dragon)` ✔（与 7H 相同）。
* **已核实**：GameTest 断言了 `victim.getLastHurtByMob() == dragon` ✔；实机第 5 阶段也读到同一归属 ✔。
* **未核实**：目标**是否会反击** ✗ —— 我的所有测试目标都 `setNoAi(true)`（为的是让测量可重复），这**恰恰会让 `HurtByTargetGoal` 不工作** ⇒ 本轮**不能**回答"某生物会不会反击"，也没有据此改动任何伤害或 AI 代码 ✔。若要在实机确认反击，需要一个**开启 AI** 的僵尸/骷髅类目标与独立的一次会话（列为待办，§7）。


### 4.3 编译

`gradlew compileJava` → **BUILD SUCCESSFUL（33s）**，日志 `build\c8a1.log`。**没有出现任何 Forge/Citadel API 错误**，因此**没有做任何最小修正**（补丁引用的 `holdStill()`、`setSitting()`、`SoulfireOrders.skyOpen()`、`walkTo/horizontalTo`、`breatheAt()`、`ClipContext`、`HitResult`、`EntityType.HUSK` 在当前运行 jar 中均存在）。

> 说明：编译通过 ≠ 游戏内喷吐成功；GameTest 与实机结果分别见 §5、§6。

---

## 5. GameTest 结果（权威，逐服务端 tick）

运行：`build\gametest8a1.log`（第一次，**185 项** = 7I 的 183 + 8A 的 2 项）结果 **10 项失败 / BUILD FAILED（12m）**；
`build\gametest8a2.log`（第二次，**189 项** = 加上我方 4 项补充测试）结果 **12 项失败**，其中与本事相关的只有 4 项（补丁 8A 的 2 项 + 我方墙测试 1 项 + 下详），其余为 7I 三条转向失败与既有不稳定项。

### 5.1 8A 自带的两个测试：**两项都失败** ✗（原样保留，不修改）

```
groundbreathcreditsdragon failed! soulfire beam did not damage the husk; inspect muzzle and ray obstruction
nearbygroundskilldoesnottakeoff failed! nearby ground breath took off or failed to execute: fly=true hover=false breath=true
```

**原因判定（与产品行为无关，属测试放置位置）**：`humanspawn_flat` 是 **5×3×5** 的平台，而该测试把目标放在 `(2,1,8)` —— **在平台之外**，于是目标落到测试世界的地形上、射线被外部地形挡住（第 1 条），并且受试者的"在地面"前置条件也不成立（第 2 条 `fly=true`）。
**我没有改这两个测试**（它们的判定照旧保留在此）；作为对照，我用**同一套断言、正确的世界坐标**另写了一个文件（§5.2）。

### 5.2 我方补充测试（新增文件，明确标注）


---

## 7. 未验证 / 已知限制（如实注明）

| # | 事项 | 现状 |
|---|---|---|

---

## 11. 本轮结论与下一步（**停止等待玩家验收**）

**Stage 1 判定：不完全通过** ✗ —— 有明确的通过项，也有**一项明确失败**。

| 分类 | 项目 |
|---|---|
| ✔ **已验证成立** | 伤害归属（`getLastHurtByMob()==dragon`，GameTest）；近距离吐息**不离开地面**（GameTest 两项，含"先站定再下令"）；友军保护（实机：女王与她的一条同类在射流中毫发无损、同一条射流里的陌生者掉血）；远距离 BOMBARD **无回归**（实机：照旧起飞并持续吐息）；编译无 API 错误；既有 `soulfire_dragon`/`soulfire_multipart` GameTest 无回归 |
| ✗ **明确失败** | **实心墙遮挡**：`thebeamdoesnotpassthroughasolidwall` → `20.0 -> 18.08`，实机同现象 `20 → 5.3` ⇒ **射线/伤害穿过 3×3 实心石墙** |
| ✗ **无法判定** | 实机"站立/行走/侧面扭头/地面 ATTACK"四项（探针未建立"站在地面"前置条件，§6.3）；粒子速度（无数值测量）；目标**是否反击**（测试目标关闭 AI）；7I 逐 tick 转向（未关闭，照旧失败） |
| ✗ **补丁自带测试** | `groundbreathcreditsdragon`、`nearbygroundskilldoesnottakeoff` 两项失败，原因判定为测试把目标放在 5×5 平台之外（§5.1），我**未修改**它们 |

**因此：不安装 Stage 2** ✔（符合任务书"只有 Stage 1 通过验收，才应用 Stage 2"）。

**下一步（等玩家决定，我不擅自改产品逻辑）**：

1. **墙的问题**：排查为何两条 `level.clip(muzzle → 目标, Block.COLLIDER)` 都没能挡住石墙——例如 `burn()` 的搜索盒 `inflate(HEAD_ROOM=3.0)` 让"命中判定"与"射线判定"用了不同几何、或火焰/伤害两条路径中被某处提前返回的写法绕开；修完请重跑 `thebeamdoesnotpassthroughasolidwall`（它就是验收线）。
2. **实机四项**：等墙的问题修好后，用同一探针再跑一次（探针已加"每阶段起点打印 `onGround/flying/hovering`"，可明确区分"产品失败"与"前置条件未建立"）。
3. **粒子速度**：如需数值证据，需要在客户端侧对粒子做取样（当前环境只做了代码路径核对）。
4. **反击行为**：用**开启 AI** 的僵尸/骷髅单独测一次 `HurtByTargetGoal`。
5. **7I 转向**：仍按未关闭问题挂账 ✗（本轮未触碰运动/朝向控制权）。

---

## 12. 交付物清单

| 类别 | 路径 | 说明 |
|---|---|---|
| 编译日志 | `build\c8a1.log` | `compileJava` BUILD SUCCESSFUL（33s，无 API 错误） |
| GameTest | `build\gametest8a1.log` | 第一次运行（185 项，10 项失败） |
| GameTest | `build\gametest8a2.log` | 第二次运行（189 项，含我方 4 项补充测试） |
| 实机日志 | `build\probe_8a1.log`、`build\probe_8a2.log` | 吐息探针两次（判定一致） |
| 部署日志 | `build\deploy8a1.log`、`deploy8a2.log`、`deploy8a3.log` | 三次构建部署（BUILD SUCCESSFUL） |
| 哈希脚本 | `build\hashcheck8a.py` | 与安装器同算法的归一化哈希复核（§4.1） |
| 帧序列 | `build\probe_shots\round8a\`（22 张） | 站立/行走/扭头/墙/友军/攻击/轰炸 |
| 部署 jar | 源 `build\libs\spiderqueen_hungrycraft-0.0.1-dev.jar`（6823 KB，22:54:15）<br>目标 `…\1.20.1-Forge_47.4.23\mods\` | SHA-256 `8076F2ACF5B4663B2F8418394AF2FEF1493CBC4E6E2639548FB10EEB5D69001D` |
| 我方新增源码 | `client\Soulfire8ABreathProbe.java`、`soulfire\Soulfire8AGroundBreathGameTest.java` | 实机吐息探针；坐标正确的补充 GameTest（明确标注为 DS 新增） |
| 补丁与备份 | ZIP SHA-256 `392F36D46476B0FD5A31BC42A4BB55651FA8F76C2D7D1B0968C78B6FD553BBE5`<br>`_patches\Soulfire8A\`（含 `apply_patch.py`/`rollback_patch.py`/`manifest.json`）<br>`_backups\round8a_before\`（42 文件）<br>`_soulfire8a_external_backups\stage1_20261010_222417_795452\` | 全部可复核、可回滚 |
| 本报告 | `D:\MinecraftModding\NecromancyIV_Astra_Handoff\ROUND8A_COMBAT_AND_MULTIPART_VALIDATION.md` | 编译 / GameTest / 客户端启动 / 实机 / 未验证项 / 实际失败，逐项区分 |

| 1 | 实机的"站立/行走/侧面扭头/墙后目标"四项 | **未取得判定** ✗（探针未能建立"站在地面"的前置条件，证据见 §6.3）；同一批断言改由 §5.2 的确定性 GameTest 回答 |
| 2 | 粒子的**运动速度**（`PARTICLE_SPEED=0.28`） | 只做了**代码路径核对**（`count=0` 的单粒子分支 + 前向速度向量）+ 帧序列观察 ✗；**没有**做数值测量（客户端粒子引擎不暴露速度读数） |
| 3 | 目标生物**是否会反击** | **未核实** ✗（测试目标全部 `setNoAi(true)`，恰恰会让 `HurtByTargetGoal` 失效）。`lastHurtByMob == dragon` 已核实 ✔；反击需要在开启 AI 的会话里单独验证 |
| 4 | 7I 的逐 tick 转向断言 | **仍然失败** ✗（§5.3），本轮按任务要求只记录、不修复 |
| 5 | 多人 / 专用服务器 | 未测 ✗（只在集成服务端 + 本地客户端） |
| 6 | 8A 自带的两个 GameTest | **失败** ✗，原因判定为测试放置位置（§5.1）；我**没有**修改它们 |
| 7 | 近距离锥角的细节差异 | 本地 7H 版对 `distance <= 0.5` 的目标跳过锥角检查，8A 版一律检查 ⇒ 贴脸且在瞄准线后的目标行为可能不同（记录备查，未改） |
| 8 | `SoulfireBreath` 的类级设计注释 | 8A 版把它换成了简短注释 ⇒ 属文档退化（未擅自改回，见 §10 待办） |

---

## 8. 本轮**未触碰**的东西（与任务一致）

* I&F 原生龙 AI、原始龙骨身份/复活、骑乘、蓝眼睛 —— 全部未触碰 ✔（蓝眼仍是 7H 的"撤掉图层注册"状态）。
* 骨龙模型、动画调用链、独立飞行与降落逻辑 —— 未改 ✔（唯一的飞行相关改动来自 8A 的"地面吐息不起飞"分支）。
* **Git**：HEAD 仍为 `34a97714bef7a5a130461d737e73f5a3629dc978`；**未执行** `reset/clean/checkout/commit/add/stash` ✔。
* 备份可回滚（§9）✔。

---

## 9. 回滚

1. 安装器回滚（先回 Stage 2 再回 Stage 1；只适用于未在其上再次编辑的代码）：
   ```powershell
   py -3 D:\MinecraftModding\_patches\Soulfire8A\rollback_patch.py "D:\MinecraftModding\SpiderQueen-HungryCraft-Forge-1.20.1" "D:\MinecraftModding\_soulfire8a_external_backups\stage1_20261010_222417_795452"
   ```
2. 或用我的整目录备份覆盖：
   ```powershell
   Copy-Item D:\MinecraftModding\_backups\round8a_before\soulfire\* <工程>\src\main\java\spiderqueenhungrycraft\soulfire\ -Recurse -Force
   Copy-Item D:\MinecraftModding\_backups\round8a_before\compat\iceandfire\* <工程>\src\main\java\spiderqueenhungrycraft\compat\iceandfire\ -Recurse -Force
   ```
   并删除本轮新增的两个文件：`Soulfire8ACombatGameTest.java`（补丁新增）、`Soulfire8AGroundBreathGameTest.java`（我方补充）。

---

## 10. Stage 2：**未安装**，等待 Stage 1 验收

按任务书，Stage 2 只有在 Stage 1 通过玩家验收后才安装，且必须**同时**满足：

1. 服务端 `getEntityOrPart()` 能找到六个部件；
2. F3+B 能看到位置合理的头、颈、身体、双翼、尾部区域；
3. **真实箭矢**分别命中头、翼、尾并让主体受伤（禁止用 `part.hurt()` 代替）；
4. 玩家点击子部件仍能通过归属检查，选中所属灵火龙；
5. 客户端与服务端部件位置一致；
6. 主体离开视野但翼骨仍可见时不被错误剔除；
7. 死亡 / 契约到期 / 区块卸载后不遗留幽灵部件；
8. 多只骨龙不出现实体 ID 冲突或严重 TPS 下降；原有 MOVE/FOLLOW/HOLD/降落/契约恢复不回归。

**纪律**：Stage 2 **禁止**再用 `addFreshEntity(part)` 周期性注册部件 ✔；若服务端索引正确而箭矢仍不命中，必须继续核对 `ProjectileCanBeHit`/射线查询/部件碰撞/端间同步，**不得宣布成功** ✔。

`src/main/java/spiderqueenhungrycraft/soulfire/Soulfire8AGroundBreathGameTest.java`（batch `soulfire8a_groundbreath`，4 项）：受试者与目标**都在平台之内**，断言分别为——伤害到达 + 归属为龙、近距离吐息不离开地面、**结算之后**才下令同样不离开地面、以及**实心墙必须挡住射线**。
**结果（`build\gametest8a2.log`）**：

| 我方测试 | 结果 | 读数 |
|---|---|---|
| `groundbreathreachthevictimandiscreditedtothedragon` | **通过** ✔ | 目标掉血且 `getLastHurtByMob()==dragon` |
| `anearbypointisburntwithoutleavingthefloor` | **通过** ✔ | 近距离点被烧，全程未离开地面 |
| `anearbypointisburntaftertheanimalhassettled` | **通过** ✔ | 先站定再下令，同样不离开地面 |
| `thebeamdoesnotpassthroughasolidwall` | **失败** ✗ | `a victim behind solid stone takes nothing: 20.0 -> 18.08` —— **射线/伤害穿过了 3×3 的实心石墙** |

⇒ 结论：8A 的"地面吐息不起飞"与"伤害归属"在**正确放置**的前提下**成立** ✔；但**"实心墙遮挡"不成立** ✗ —— 该项与实机第 4 阶段（husk 20→5.3）**两次独立测量一致** ✗。

### 5.3 7I 的转向失败记录：**复现并保留** ✗

```
flightmotionfollowsdragonsfacing failed! air motion disagrees with yaw: 0.50079793403370
afullreversalturnsinsteadofflyingbackwards failed! no turn over 8.05 degrees in one tick
aninetydegreeorderturnsbeforeitflies failed! no turn over 8.05 degrees in one tick: 48.2
```

按任务要求，**玩家肉眼能转弯 ≠ 逐 tick 断言通过**；本轮**没有**触碰运动/朝向控制权，这条未关闭问题**照旧挂账** ✗。

### 5.4 与 7H/7I 的回归对比

本次运行中 `soulfire_dragon:1`（19 项）与 `soulfire_multipart:1`（5 项）**没有任何失败行** ✔ ⇒ 吐息改动没有破坏既有骨龙行为 ✔。
与本轮无关的既有不稳定项（每次运行集合不同）✗：`identityandpopulation`、`territorycore_…`、`aswingistheswingofthegameanditmovestheweaponarm`、`meleeswingsofeveryhumanoidbodyreallyremovehealth`、`guidancehelpsagainstadodgeandleavesanoncourseshotalone`。
