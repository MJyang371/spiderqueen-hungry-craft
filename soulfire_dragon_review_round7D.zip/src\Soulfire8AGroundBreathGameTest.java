package spiderqueenhungrycraft.soulfire;

import net.minecraft.core.BlockPos;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.monster.Husk;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.gametest.GameTestHolder;
import net.minecraftforge.gametest.PrefixGameTestTemplate;
import spiderqueenhungrycraft.SpiderQueenHungryCraft;
import spiderqueenhungrycraft.registry.HungryCraftEntities;

/**
 * The two claims of round 8A stage 1, asked again on a floor that both animals really stand on (added by DS).
 *
 * <p><b>Why this file exists.</b> The patch's own {@code Soulfire8ACombatGameTest} puts its victim six blocks outside the
 * five by five platform of the template, so the victim lands on whatever terrain the test world happens to have there and
 * the beam is tested against the world instead of against the animal. Its two tests fail for that reason alone. This file
 * asks the very same two questions with both animals inside the template, exactly as a game test structure is meant to be
 * used. It changes no product behaviour and it does not touch the patch's tests: their verdict stands beside this one.
 */
@GameTestHolder(SpiderQueenHungryCraft.MODID)
@PrefixGameTestTemplate(false)
public final class Soulfire8AGroundBreathGameTest
{
    /** Where the dragon stands: inside the platform, with clear air in front of it. */
    private static final BlockPos DRAGON_POS = new BlockPos(1, 1, 1);

    /** Where the victim stands: also inside the platform, two blocks in front of the jaws. */
    private static final BlockPos VICTIM_POS = new BlockPos(1, 1, 4);

    private Soulfire8AGroundBreathGameTest()
    {
    }

    private static void expect(GameTestHelper helper, String what, boolean ok)
    {
        if (!ok)
        {
            helper.fail(what);
        }
    }

    /** One unit and one victim, both on the floor of the structure, both facing +Z. */
    private static SoulfireDragonEntity pairOnTheFloor(GameTestHelper helper)
    {
        SoulfireDragonEntity dragon = helper.spawn(HungryCraftEntities.SOULFIRE_DRAGON.get(), DRAGON_POS);
        dragon.setStage(2);
        dragon.setYRot(0.0F);
        dragon.yBodyRot = 0.0F;

        return dragon;
    }

    /** The beam of a dragon that stands on the floor must reach a victim that stands on the same floor, and be its work. */
    @GameTest(template = "humanspawn_flat", batch = "soulfire8a_groundbreath", timeoutTicks = 100)
    public static void groundbreathreachthevictimandiscreditedtothedragon(GameTestHelper helper)
    {
        SoulfireDragonEntity dragon = pairOnTheFloor(helper);
        Husk victim = helper.spawn(EntityType.HUSK, VICTIM_POS);
        victim.setNoAi(true);

        float before = victim.getHealth();

        SoulfireBreath.tick(dragon, victim.getBoundingBox().getCenter());

        expect(helper, "the beam of a standing dragon reaches a victim on the same floor: " + before + " -> "
                + victim.getHealth(), victim.getHealth() < before);
        expect(helper, "and the damage is the dragon's work: " + victim.getLastHurtByMob(),
                victim.getLastHurtByMob() == dragon);
        helper.succeed();
    }

    /** A nearby point must be burnt where the animal stands: the order is not a flight order. */
    @GameTest(template = "humanspawn_flat", batch = "soulfire8a_groundbreath", timeoutTicks = 120)
    public static void anearbypointisburntwithoutleavingthefloor(GameTestHelper helper)
    {
        SoulfireDragonEntity dragon = pairOnTheFloor(helper);

        dragon.breatheAt(helper.absolutePos(VICTIM_POS));

        int[] ticks = {0};
        boolean[] flew = {false};
        int[] breathing = {0};

        helper.onEachTick(() ->
        {
            ticks[0]++;
            flew[0] = flew[0] || dragon.isFlying() || dragon.isHovering();
            breathing[0] += dragon.isBreathing() ? 1 : 0;

            if (ticks[0] == 40)
            {
                expect(helper, "the nearby point was really burnt: " + breathing[0] + " breathing ticks",
                        breathing[0] >= 25);
                expect(helper, "and the animal never left the floor for it: flying=" + dragon.isFlying() + " hovering="
                        + dragon.isHovering() + " (seen at all: " + flew[0] + ")", !flew[0]);
                helper.succeed();
            }
        });
    }

    /** The same order, given after the animal has stood for a while: a settling animal must not change the answer. */
    @GameTest(template = "humanspawn_flat", batch = "soulfire8a_groundbreath", timeoutTicks = 200)
    public static void anearbypointisburntaftertheanimalhassettled(GameTestHelper helper)
    {
        SoulfireDragonEntity dragon = pairOnTheFloor(helper);

        int[] ticks = {0};
        boolean[] ordered = {false};
        boolean[] flew = {false};
        int[] breathing = {0};
        boolean[] groundedAtOrder = {false};

        helper.onEachTick(() ->
        {
            ticks[0]++;

            // Only after the animal really stands does the order go out, so a slow settling can never be mistaken for a
            // product failure.
            if (!ordered[0] && ticks[0] > 20 && dragon.onGround() && !dragon.isFlying() && !dragon.isHovering())
            {
                ordered[0] = true;
                groundedAtOrder[0] = true;
                dragon.breatheAt(helper.absolutePos(VICTIM_POS));
            }

            if (ordered[0])
            {
                flew[0] = flew[0] || dragon.isFlying() || dragon.isHovering();
                breathing[0] += dragon.isBreathing() ? 1 : 0;
            }

            if (ticks[0] == 140)
            {
                expect(helper, "the order was given while the animal stood: " + groundedAtOrder[0], groundedAtOrder[0]);
                expect(helper, "the nearby point was really burnt: " + breathing[0] + " breathing ticks",
                        breathing[0] >= 25);
                expect(helper, "and the animal never left the floor for it: flying=" + dragon.isFlying() + " hovering="
                        + dragon.isHovering() + " (seen at all: " + flew[0] + ")", !flew[0]);
                helper.succeed();
            }
            else if (ticks[0] > 180)
            {
                helper.fail("the animal never settled on the floor: onGround=" + dragon.onGround() + " flying="
                        + dragon.isFlying() + " hovering=" + dragon.isHovering());
            }
        });
    }

    /** Solid stone between the jaws and a victim: the beam must stop at the wall, not pass through it. */
    @GameTest(template = "humanspawn_flat", batch = "soulfire8a_groundbreath", timeoutTicks = 40)
    public static void thebeamdoesnotpassthroughasolidwall(GameTestHelper helper)
    {
        SoulfireDragonEntity dragon = pairOnTheFloor(helper);
        Husk victim = helper.spawn(EntityType.HUSK, VICTIM_POS);
        victim.setNoAi(true);

        // A wall of stone right between the two of them, three wide and three high.
        BlockPos wall = helper.absolutePos(DRAGON_POS.offset(0, 0, 2));
        int floor = wall.getY();

        for (int dx = -1; dx <= 1; dx++)
        {
            for (int dy = 0; dy <= 2; dy++)
            {
                helper.getLevel().setBlockAndUpdate(new BlockPos(wall.getX() + dx, floor + dy, wall.getZ()),
                        net.minecraft.world.level.block.Blocks.STONE.defaultBlockState());
            }
        }

        float before = victim.getHealth();

        SoulfireBreath.tick(dragon, victim.getBoundingBox().getCenter());

        expect(helper, "a victim behind solid stone takes nothing: " + before + " -> " + victim.getHealth(),
                Math.abs(victim.getHealth() - before) < 0.001F);

        // The same victim, now with the wall taken away, must take damage - proof that only the wall saved it.
        for (int dx = -1; dx <= 1; dx++)
        {
            for (int dy = 0; dy <= 2; dy++)
            {
                helper.getLevel().setBlockAndUpdate(new BlockPos(wall.getX() + dx, floor + dy, wall.getZ()),
                        net.minecraft.world.level.block.Blocks.AIR.defaultBlockState());
            }
        }

        SoulfireBreath.tick(dragon, victim.getBoundingBox().getCenter());

        expect(helper, "and with the wall gone the very same beam does reach it: " + before + " -> " + victim.getHealth(),
                victim.getHealth() < before);
        helper.succeed();
    }
}
